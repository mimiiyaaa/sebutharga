<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['contacts' => collect()]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['contacts' => collect()]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div x-data="{
    search: '',
    matches(contact) {
        const query = this.search.trim().toLowerCase();
        if (!query) return true;
        return [
            contact.code,
            contact.name,
            contact.company,
            contact.address,
            contact.phone,
            contact.email,
            contact.reference,
        ].join(' ').toLowerCase().includes(query);
    },
    reset() { this.search = ''; }
}">
    <div class="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div class="relative min-w-0 flex-1">
            <input x-model="search" type="search" placeholder="<?php echo e(__('Cari kod, nama, syarikat, telefon atau e-mel')); ?>" aria-label="<?php echo e(__('Cari pelanggan atau pembekal')); ?>" class="h-11 w-full rounded-lg border border-gray-200 bg-white px-3 text-sm text-gray-700 shadow-theme-xs outline-none transition focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300">
        </div>
        <button type="button" @click="reset()" class="h-11 rounded-lg border border-gray-300 bg-white px-4 text-sm font-medium text-gray-700 shadow-theme-xs transition hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700"><?php echo e(__('Reset')); ?></button>
    </div>

    <div class="overflow-x-auto custom-scrollbar">
    <table class="w-full min-w-[900px]">
        <thead>
            <tr class="border-b border-gray-100 dark:border-gray-800">
                <?php $__currentLoopData = ['Kod', 'Nama', 'Nama Syarikat', 'Alamat', 'Nombor Telefon', 'E-mel', 'No. Rujukan', 'Tindakan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heading): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th class="px-5 py-3 text-start sm:px-6"><p class="font-medium text-gray-500 text-theme-xs dark:text-gray-400"><?php echo e($heading); ?></p></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr x-show="matches({ code: <?php echo \Illuminate\Support\Js::from($contact->customer_code)->toHtml() ?>, name: <?php echo \Illuminate\Support\Js::from($contact->customer_name ?: '')->toHtml() ?>, company: <?php echo \Illuminate\Support\Js::from($contact->company_name)->toHtml() ?>, address: <?php echo \Illuminate\Support\Js::from($contact->address)->toHtml() ?>, phone: <?php echo \Illuminate\Support\Js::from($contact->phone_no ?: '')->toHtml() ?>, email: <?php echo \Illuminate\Support\Js::from($contact->email ?: '')->toHtml() ?>, reference: <?php echo \Illuminate\Support\Js::from($contact->reference_no ?: '')->toHtml() ?> })" class="border-b border-gray-100 dark:border-gray-800">
                    <td class="px-5 py-4 text-gray-500 text-theme-sm dark:text-gray-400"><?php echo e($contact->customer_code); ?></td>
                    <td class="px-5 py-4 text-gray-800 text-theme-sm dark:text-white/90"><?php echo e($contact->customer_name ?: '—'); ?></td>
                    <td class="px-5 py-4 text-gray-800 text-theme-sm dark:text-white/90"><?php echo e($contact->company_name); ?></td>
                    <td class="max-w-xs px-5 py-4 text-gray-500 text-theme-sm dark:text-gray-400"><?php echo e($contact->address); ?></td>
                    <td class="px-5 py-4 text-gray-500 text-theme-sm dark:text-gray-400"><?php echo e($contact->phone_no ?: '—'); ?></td>
                    <td class="px-5 py-4 text-gray-500 text-theme-sm dark:text-gray-400"><?php echo e($contact->email ?: '—'); ?></td>
                    <td class="px-5 py-4 text-gray-500 text-theme-sm dark:text-gray-400"><?php echo e($contact->reference_no ?: '—'); ?></td>
                    <td class="whitespace-nowrap px-5 py-4">
                        <div class="flex items-center gap-2">
                            <a href="<?php echo e(route('contacts.show', ['type' => request()->is('pembekal*') ? 'pembekal' : 'pelanggan', 'id' => $contact->customer_id])); ?>" class="inline-flex items-center rounded-lg border border-gray-200 px-3 py-1.5 text-xs font-medium text-gray-600 transition hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-white/[0.05]"><?php echo e(__('Lihat')); ?></a>
                            <a href="<?php echo e(route('contacts.edit', ['type' => request()->is('pembekal*') ? 'pembekal' : 'pelanggan', 'id' => $contact->customer_id])); ?>" class="inline-flex items-center rounded-lg bg-brand-500 px-3 py-1.5 text-xs font-medium text-white transition hover:bg-brand-600"><?php echo e(__('Edit')); ?></a>
                            <form method="POST" action="<?php echo e(route('contacts.delete', ['type' => request()->is('pembekal*') ? 'pembekal' : 'pelanggan', 'id' => $contact->customer_id])); ?>" @submit.prevent="$dispatch('confirm-action', { form: $el, message: 'Padam rekod ini?' })"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button type="submit" title="<?php echo e(__('Padam')); ?>" aria-label="<?php echo e(__('Padam')); ?>" class="inline-flex items-center justify-center rounded-lg border border-error-200 p-2 text-error-600 transition hover:bg-error-50 dark:border-error-700 dark:text-error-400 dark:hover:bg-error-500/10"><svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M6 7h12m-9 0V5h6v2m-7 0 1 13h6l1-13M10 11v5m4-5v5"/></svg></button></form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="8" class="px-5 py-10 text-center text-gray-500 text-theme-sm dark:text-gray-400">Tiada rekod untuk dipaparkan.</td></tr>
            <?php endif; ?>
            <tr x-cloak x-show="search && !Array.from($el.parentElement.querySelectorAll('tr[x-show]')).some(row => row.offsetParent !== null)"><td colspan="8" class="px-5 py-10 text-center text-gray-500 text-theme-sm dark:text-gray-400"><?php echo e(__('Tiada rekod sepadan dengan carian.')); ?></td></tr>
        </tbody>
    </table>
    </div>
</div>
<?php /**PATH C:\laragon\www\sebutharga\resources\views\components\tables\basic-tables\customer-table.blade.php ENDPATH**/ ?>