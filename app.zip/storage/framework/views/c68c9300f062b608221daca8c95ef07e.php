<?php
    $document = App\Helpers\QuotationDocument::data($detail);
    $quotation = clone $quotation;
    $detail = clone $detail;
    foreach (['customer_name', 'company_name', 'phone_no', 'email', 'address'] as $field) {
        if (array_key_exists($field, $document)) $quotation->$field = $document[$field];
    }
    foreach (['disediakan_role', 'disediakan_company_name', 'diterima_role'] as $field) {
        if (array_key_exists($field, $document)) $detail->$field = $document[$field];
    }
    $companyLogo = null;
    if (isset($company) && $company?->logo_path) {
        $logoPath = \Illuminate\Support\Facades\Storage::disk('public')->path($company->logo_path);
        if (is_file($logoPath)) {
            $companyLogo = 'data:' . (mime_content_type($logoPath) ?: 'image/png') . ';base64,' . base64_encode(file_get_contents($logoPath));
        }
    }
?>
<!doctype html>
<html lang="ms">
<head>
<meta charset="utf-8">
<title><?php echo e($quotation->quotation_no); ?></title>
<style>
@page { margin: 25pt; }
* { box-sizing: border-box; }
body { margin: 0; color: #000; background: #fff; font-family: Helvetica, Arial, sans-serif; font-size: 10pt; line-height: 1.3; }
table { width: 100%; border-collapse: collapse; }
.header td { vertical-align: top; padding: 0 0 15pt; }
.company { font-size: 16pt; font-weight: bold; color: #800000; }
.company-block { width: auto; }
.company-block td { padding: 0; vertical-align: top; }
.company-logo { max-width: 42pt; max-height: 38pt; object-fit: contain; margin-right: 8pt; }
.document-title { font-size: 14pt; font-weight: bold; color: #800000; }
.contact { font-size: 9pt; }
.document-meta { width: 32%; text-align: right; }
.rule { border-top: 1pt solid #800000; }
.recipient { margin: 15pt 0; font-size: 10pt; }
.quotation-title { margin: 0 0 8pt; font-size: 11pt; font-weight: bold; }
.address, .terms-copy { white-space: pre-line; overflow-wrap: break-word; }
.items { table-layout: fixed; }
.items th { background: #800000; color: white; border: .5pt solid #000; padding: 5pt 3pt; font-size: 10pt; text-align: center; }
.items td { border: .5pt solid #ccc; padding: 5pt 3pt; vertical-align: middle; overflow-wrap: break-word; }
.items thead { display: table-header-group; }
.items tr { page-break-inside: avoid; }
.bil { width: 6%; text-align: center; }
.description { width: 46%; }
.quantity { width: 12%; text-align: center; }
.unit { width: 8%; text-align: center; }
.price { width: 14%; text-align: right; }
.amount { width: 14%; text-align: right; }
.total td { padding: 3pt 2pt; font-weight: bold; text-align: right; }
.total-value { width: 14%; border-bottom: 2pt solid #800000; }
.terms { margin-top: 16pt; font-size: 10pt; page-break-inside: avoid; }
.signatures { margin-top: 30pt; page-break-inside: avoid; }
.signatures td { width: 50%; vertical-align: top; }
.signature-right { text-align: right; }
.signature-space { height: 55pt; }
.signature-block { display: inline-block; min-width: 110pt; border-top: 1pt dotted #777; padding-top: 3pt; font-weight: bold; }
.signature-right .signature-block { text-align: center; }
@media screen { body { padding: 33px; } }
</style>
</head>
<body>
<table class="header"><tr>
<td>
<table class="company-block"><tr>
<?php if($companyLogo): ?><td><img class="company-logo" src="<?php echo e($companyLogo); ?>" alt="Logo Syarikat"></td><?php endif; ?>
<td>
<div class="company"><?php echo e((array_key_exists('issuer_name', $document) ? $document['issuer_name'] : config('purchase_order.issuer_name'))); ?></div>
<div class="contact address"><?php echo e((array_key_exists('issuer_address', $document) ? $document['issuer_address'] : ($quotation->alamat_syarikat ?? config('purchase_order.issuer_address')))); ?></div>
<?php
    $issuerPhone = array_key_exists('issuer_phone', $document) ? $document['issuer_phone'] : config('purchase_order.issuer_phone');
    $issuerEmail = array_key_exists('issuer_email', $document) ? $document['issuer_email'] : config('purchase_order.issuer_email');
?>
<div class="contact">
    <?php if($issuerPhone): ?>No. Tel: <?php echo e($issuerPhone); ?><?php endif; ?>
    <?php if($issuerPhone && $issuerEmail): ?> | <?php endif; ?>
    <?php if($issuerEmail): ?>E-mel: <?php echo e($issuerEmail); ?><?php endif; ?>
</div>
</td></tr></table>
</td>
<td class="document-meta"><div class="document-title">SEBUTHARGA</div>
<strong>No: <?php echo e($quotation->quotation_no); ?></strong>
<div class="contact">Tarikh: <?php echo e(\Carbon\Carbon::parse($quotation->quotation_date)->locale('ms')->translatedFormat('d F Y')); ?></div>
</td></tr></table>
<div class="rule"></div>
<div class="recipient"><strong>Kepada:</strong><br>
<span><?php echo e($quotation->customer_name ?: $quotation->company_name); ?></span><?php if($quotation->customer_name && $quotation->company_name && $quotation->customer_name !== $quotation->company_name): ?><br><span><?php echo e($quotation->company_name); ?></span><?php endif; ?>
<div class="address"><?php echo e($quotation->address ?? ''); ?></div>
<?php if(!empty($quotation->phone_no)): ?><div>No. Tel: <?php echo e($quotation->phone_no); ?></div><?php endif; ?>
<?php if(!empty($quotation->email)): ?><div>E-mel: <?php echo e($quotation->email); ?></div><?php endif; ?>
</div>
<?php if(!empty($quotation->quotation_title)): ?><div class="quotation-title"><?php echo e($quotation->quotation_title); ?></div><?php endif; ?>
<table class="items">
<thead><tr><th class="bil">BIL</th><th class="description">KETERANGAN / DESCRIPTION</th><th class="quantity">KUANTITI</th><th class="unit">UNIT</th><th class="price">HARGA<br>SEUNIT<br>(RM)</th><th class="amount">JUMLAH<br>(RM)</th></tr></thead>
<tbody>
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr><td class="bil"><?php echo e($index + 1); ?></td><td class="description"><?php echo e($item->item_description); ?></td><td class="quantity"><?php echo e($item->quantity); ?></td><td class="unit"><?php echo e($item->unit); ?></td><td class="price"><?php echo e(number_format((float) $item->unit_price, 2)); ?></td><td class="amount"><?php echo e(number_format((float) $item->subtotal, 2)); ?></td></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody></table>
<table class="total"><tr><td>JUMLAH BESAR (RM):</td><td class="total-value"><?php echo e(number_format((float) $detail->jumlah_total, 2)); ?></td></tr></table>
<div class="terms"><strong>TERMA DAN SYARAT / TERMS &amp; CONDITIONS:</strong>
<div class="terms-copy"><?php echo e($detail->terma_syarat ?: "1. Tempoh sah sebutharga adalah 30 hari dari tarikh sebutharga dikeluarkan.
2. Tempoh penghantaran: 14 - 30 hari selepas penerimaan Pesanan Belian (PO) rasmi.
3. Sila tandatangan di bawah untuk pengesahan persetujuan sebutharga ini."); ?></div>
</div>
<table class="signatures"><tr><td>Disediakan oleh,</td><td class="signature-right">Diterima / Disahkan oleh,</td></tr>
<tr><td class="signature-space"></td><td></td></tr>
<tr><td><div class="signature-block"><?php if($detail->disediakan_oleh): ?><?php echo e($detail->disediakan_oleh); ?><br><?php endif; ?> <?php if(property_exists($detail, 'disediakan_role') && $detail->disediakan_role): ?><?php echo e($detail->disediakan_role); ?><br><?php endif; ?> <?php if(property_exists($detail, 'disediakan_company_name') && $detail->disediakan_company_name): ?><?php echo e($detail->disediakan_company_name); ?><br><?php endif; ?></div></td>
<td class="signature-right"><div class="signature-block">Tandatangan &amp; Cop<br>Tarikh</div></td></tr></table>
</body></html>
<?php /**PATH C:\laragon\www\sebutharga\resources\views\pages\sebut-harga\pdf.blade.php ENDPATH**/ ?>