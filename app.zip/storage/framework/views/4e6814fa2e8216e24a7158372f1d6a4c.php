<?php $__env->startSection('content'); ?>
<div class="mb-6 flex justify-end">
<a href="<?php echo e((request('from') === 'final' && request('via') !== 'detail' ? route('sebut-harga.final') : route('sebut-harga.edit', [$quotation->quotation_id, 'draft' => $draft->quotation_detail_id, 'from' => request('from') === 'final' ? 'final' : 'draft']))); ?>" class="rounded-lg border border-gray-300 bg-white px-4 py-3 text-sm text-gray-700 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300"><?php echo e(__(request('from') === 'final' && request('via') !== 'detail' ? 'Kembali ke Final Sebut Harga' : 'Kembali ke Maklumat Sebut Harga')); ?></a>
</div>
<div class="mb-6 flex flex-wrap justify-end gap-3">
<a href="<?php echo e(route('sebut-harga.pdf', [$quotation->quotation_id, 'draft' => $draft->quotation_detail_id])); ?>" class="rounded-lg bg-brand-500 px-4 py-3 text-sm font-medium text-white hover:bg-brand-600 dark:bg-brand-500"><?php echo e(__('Muat Turun PDF')); ?></a>
</div>
<div class="overflow-x-auto rounded-2xl border border-gray-200 bg-gray-50 p-4 dark:border-gray-800 dark:bg-gray-900">
<iframe title="<?php echo e($quotation->quotation_no); ?>" sandbox class="mx-auto block h-[1123px] w-[794px] border-0 bg-white shadow-theme-sm dark:bg-white" srcdoc="<?php echo e(view('pages.sebut-harga.pdf', ['quotation' => $quotation, 'detail' => $draft, 'items' => $draft->items, 'company' => $company])->render()); ?>"></iframe>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sebutharga\resources\views\pages\sebut-harga\preview.blade.php ENDPATH**/ ?>