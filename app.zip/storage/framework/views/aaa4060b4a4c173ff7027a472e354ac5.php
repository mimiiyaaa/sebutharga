<?php $__env->startSection('content'); ?>
    <div class="mb-6 flex flex-wrap items-center justify-between gap-3">
        <h2 class="text-xl font-semibold text-gray-800 dark:text-white/90"><?php echo e($contact ? __('Edit '.ucfirst($type)) : __('Tambah '.ucfirst($type))); ?></h2>
        <a href="<?php echo e(url('/'.$type)); ?>" class="inline-flex h-10 items-center justify-center rounded-lg border border-gray-300 bg-white px-4 text-sm font-medium text-gray-700 transition hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 dark:hover:bg-gray-800"><?php echo e(__('Kembali')); ?></a>
    </div>
    <div class="w-full">
        <form method="POST" action="<?php echo e(route('contacts.save', ['type' => $type, 'id' => $contact?->customer_id])); ?>" class="space-y-6">
            <?php echo csrf_field(); ?>
            <?php if (isset($component)) { $__componentOriginal6054fcb7c372d34a0111bcdc769744fa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6054fcb7c372d34a0111bcdc769744fa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.common.document-card','data' => ['title' => $contact ? __('Kemaskini Maklumat') : __('Maklumat '.ucfirst($type)),'desc' => __('Lengkapkan maklumat di bawah untuk disimpan dalam sistem.')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.document-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($contact ? __('Kemaskini Maklumat') : __('Maklumat '.ucfirst($type))),'desc' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Lengkapkan maklumat di bawah untuk disimpan dalam sistem.'))]); ?>
                <div class="grid grid-cols-1 gap-5 md:grid-cols-2">
                    <div>
                        <label class="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-300"><?php echo e(__('Kod')); ?></label>
                        <input readonly value="<?php echo e($contact?->customer_code ?: $generatedCode); ?>" class="min-h-11 w-full rounded-xl border border-gray-200 bg-gray-100 px-4 py-2.5 text-sm text-gray-500 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400">
                    </div>
                    <div>
                        <label for="customer_name" class="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-300"><?php echo e(__('Nama')); ?></label>
                        <input id="customer_name" name="customer_name" value="<?php echo e(old('customer_name', $contact?->customer_name)); ?>" class="min-h-11 w-full rounded-xl border border-gray-200 bg-gray-50/70 px-4 py-2.5 text-sm text-gray-800 outline-none transition focus:border-brand-500 focus:bg-white focus:ring-2 focus:ring-brand-500/20 dark:border-gray-700 dark:bg-gray-800/60 dark:text-white/90">
                    </div>
                    <?php $__currentLoopData = ['company_name' => 'Nama Syarikat', 'phone_no' => 'Nombor Telefon', 'email' => 'E-mel', 'reference_no' => 'No. Rujukan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div>
                            <label for="<?php echo e($field); ?>" class="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-300"><?php echo e(__($label)); ?> <?php if($field === 'company_name'): ?><span class="text-error-500">*</span><?php endif; ?></label>
                            <input id="<?php echo e($field); ?>" name="<?php echo e($field); ?>" type="<?php echo e($field === 'email' ? 'email' : ($field === 'phone_no' ? 'tel' : 'text')); ?>" value="<?php echo e(old($field, $contact?->$field)); ?>" <?php if($field === 'company_name'): echo 'required'; endif; ?> class="min-h-11 w-full rounded-xl border border-gray-200 bg-gray-50/70 px-4 py-2.5 text-sm text-gray-800 outline-none transition focus:border-brand-500 focus:bg-white focus:ring-2 focus:ring-brand-500/20 dark:border-gray-700 dark:bg-gray-800/60 dark:text-white/90">
                            <?php $__errorArgs = [$field];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1.5 text-sm text-error-600 dark:text-error-400"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="md:col-span-2">
                        <label for="address" class="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-300"><?php echo e(__('Alamat')); ?></label>
                        <textarea id="address" name="address" rows="4" required class="w-full rounded-xl border border-gray-200 bg-gray-50/70 px-4 py-3 text-sm text-gray-800 outline-none transition focus:border-brand-500 focus:bg-white focus:ring-2 focus:ring-brand-500/20 dark:border-gray-700 dark:bg-gray-800/60 dark:text-white/90"><?php echo e(old('address', $contact?->address)); ?></textarea>
                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1.5 text-sm text-error-600 dark:text-error-400"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6054fcb7c372d34a0111bcdc769744fa)): ?>
<?php $attributes = $__attributesOriginal6054fcb7c372d34a0111bcdc769744fa; ?>
<?php unset($__attributesOriginal6054fcb7c372d34a0111bcdc769744fa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6054fcb7c372d34a0111bcdc769744fa)): ?>
<?php $component = $__componentOriginal6054fcb7c372d34a0111bcdc769744fa; ?>
<?php unset($__componentOriginal6054fcb7c372d34a0111bcdc769744fa); ?>
<?php endif; ?>
            <div class="flex justify-end gap-3 border-t border-gray-200 pt-5 dark:border-gray-800">
                <button type="submit" class="inline-flex h-11 items-center justify-center rounded-lg bg-brand-500 px-6 text-sm font-medium text-white transition hover:bg-brand-600"><?php echo e(__('Simpan')); ?></button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sebutharga\resources\views\pages\contacts\form.blade.php ENDPATH**/ ?>