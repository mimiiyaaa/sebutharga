<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title', 'subtitle' => '', 'reference' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title', 'subtitle' => '', 'reference' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<div <?php echo e($attributes->merge(['class' => 'mx-auto max-w-7xl space-y-6 font-outfit text-theme-sm text-gray-700 dark:text-gray-300'])); ?>>
    <header class="flex flex-col gap-3 py-1 sm:flex-row sm:items-center sm:justify-between">
        <div class="flex items-center gap-4">
            <div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-peach-100 text-peach-700 dark:bg-peach-500/20 dark:text-peach-300">
                <svg class="h-5 w-5 stroke-current" fill="none" viewBox="0 0 24 24" aria-hidden="true"><path stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9l-6-6Zm0 0v6h6M8 13h8m-8 4h5"/></svg>
            </div>
            <div>
                <h1 class="text-xl font-semibold tracking-tight text-gray-900 dark:text-white/90"><?php echo e($title); ?></h1>
            </div>
        </div>
        <?php if($reference || isset($referenceActions)): ?>
            <div class="flex items-center gap-2">
                <?php if($reference): ?>
                    <span class="rounded-lg border border-gray-200 bg-gray-50 px-3 py-2 text-theme-xs font-medium text-gray-600 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300"><?php echo e($reference); ?></span>
                <?php endif; ?>
                <?php if(isset($referenceActions)): ?>
                    <?php echo e($referenceActions); ?>

                <?php endif; ?>
            </div>
        <?php endif; ?>
    </header>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\laragon\www\sebutharga\resources\views\components\common\document-workspace.blade.php ENDPATH**/ ?>