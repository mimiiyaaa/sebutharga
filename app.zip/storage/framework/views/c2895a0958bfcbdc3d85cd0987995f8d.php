<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['name' => null, 'jawatan' => null, 'email' => null, 'createdAt' => null, 'documentLabel' => 'rekod ini']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['name' => null, 'jawatan' => null, 'email' => null, 'createdAt' => null, 'documentLabel' => 'rekod ini']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div x-cloak x-show="loginInfoOpen" x-transition.origin.top.right class="absolute ltr:right-0 rtl:left-0 ltr:left-auto rtl:right-auto top-full z-999 mt-3 w-80 max-w-[calc(100vw-1rem)] overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-theme-xl dark:border-gray-700 dark:bg-gray-900">
    <div class="border-b border-gray-100 px-5 py-4 dark:border-gray-800"><h3 class="text-base font-semibold text-gray-800 dark:text-white/90"><?php echo e(__('Maklumat Login')); ?></h3><p class="mt-0.5 text-xs text-gray-500 dark:text-gray-400"><?php echo e(__('Rekod penciptaan')); ?> <?php echo e($documentLabel); ?></p></div>
    <dl class="space-y-3 px-5 py-4"><div><dt class="text-xs text-gray-500 dark:text-gray-400"><?php echo e(__('Dicipta Oleh')); ?></dt><dd class="mt-1 text-sm font-semibold text-gray-800 dark:text-white/90"><?php echo e($name ?: '—'); ?></dd></div><div><dt class="text-xs text-gray-500 dark:text-gray-400"><?php echo e(__('Jawatan')); ?></dt><dd class="mt-1 text-sm font-semibold text-gray-800 dark:text-white/90"><?php echo e($jawatan ?: '—'); ?></dd></div><div><dt class="text-xs text-gray-500 dark:text-gray-400"><?php echo e(__('E-mel')); ?></dt><dd class="mt-1 break-all text-sm font-semibold text-gray-800 dark:text-white/90"><?php echo e($email ?: '—'); ?></dd></div><div><dt class="text-xs text-gray-500 dark:text-gray-400"><?php echo e(__('Tarikh Dicipta')); ?></dt><dd class="mt-1 text-sm font-semibold text-gray-800 dark:text-white/90"><?php echo e($createdAt ? \Carbon\Carbon::parse($createdAt)->format('d/m/Y · H:i') : '—'); ?></dd></div></dl>
</div>
<?php /**PATH C:\laragon\www\sebutharga\resources\views\components\common\created-by-panel.blade.php ENDPATH**/ ?>