<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="utf-8">
    <title><?php echo e($order->po_no); ?></title>
    <style>
        @page { margin: 40pt 42pt; }
        body { font-family: Helvetica, Arial, sans-serif; font-size: 9pt; color: #000; line-height: 1.3; }
        table { width: 100%; border-collapse: collapse; }
        td, th { vertical-align: top; }
        .header td { vertical-align: top; padding: 0 0 15pt; }
        .company { color: #800000; font-size: 16pt; font-weight: bold; }
        .title { color: #800000; font-size: 16pt; font-weight: bold; }
        .company-block { width: auto; }
        .company-block td { padding: 0; vertical-align: top; }
        .company-logo { max-width: 42pt; max-height: 38pt; object-fit: contain; margin-right: 8pt; }
        .contact { font-size: 9pt; }
        .right { text-align: right; }
        .rule { border-top: 1pt solid #800000; }
        .addresses { margin-bottom: 20px; }
        .addresses td { width: 50%; padding-right: 16px; }
        .lines { white-space: pre-line; }
        .items th { background: #800000; color: white; padding: 5pt 3pt; font-size: 10pt; text-align: center; }
        .items td { border: .5pt solid #ccc; padding: 5pt 3pt; }
        .items tr { page-break-inside: avoid; }
        thead { display: table-header-group; }
        .center { text-align: center; }
        .totals { margin-top: 3px; }
        .totals td { padding: 3px 4px; font-weight: bold; }
        .net { border-top: 1px solid #111; border-bottom: 3px double #111; }
        .terms { margin-top: 16pt; font-size: 10pt; line-height: 1.3; }
        .terms h3 { font-size: 10pt; margin: 0 0 4pt; }
        .signatures { margin-top: 28px; page-break-inside: avoid; }
        .signatures td { width: 50%; padding-right: 35px; }
        .signature { margin-top: 42px; border-top: 1px dashed #333; padding-top: 5px; }
    </style>
</head>
<body>
    <?php
        $document = $document ?? [];
        $company = \Illuminate\Support\Facades\DB::table('companies')
            ->where('nama_syarikat', $document['issuer_name'] ?? '')
            ->first();
        $companyLogo = null;
        if ($company?->logo_path) {
            $logoPath = \Illuminate\Support\Facades\Storage::disk('public')->path($company->logo_path);
            if (is_file($logoPath)) {
                $companyLogo = 'data:' . (mime_content_type($logoPath) ?: 'image/png') . ';base64,' . base64_encode(file_get_contents($logoPath));
            }
        }
        $issuerPersonInCharge = $document['issuer_person_in_charge'] ?? $company?->person_in_charge;
    ?>
    <table class="header"><tr>
        <td>
            <table class="company-block"><tr>
                <?php if($companyLogo): ?><td><img class="company-logo" src="<?php echo e($companyLogo); ?>" alt="Logo Syarikat"></td><?php endif; ?>
                <td>
                    <div class="company"><?php echo e($document['issuer_name'] ?? config('purchase_order.issuer_name')); ?></div>
                    <div class="contact lines"><?php echo e($document['issuer_address'] ?? config('purchase_order.issuer_address')); ?></div>
                    <div class="contact">
                        <?php if($issuerPersonInCharge): ?>U/P: <?php echo e($issuerPersonInCharge); ?> | <?php endif; ?>
                        No. Tel: <?php echo e($document['issuer_phone'] ?? config('purchase_order.issuer_phone')); ?> | E-mel: <?php echo e($document['issuer_email'] ?? config('purchase_order.issuer_email')); ?>

                    </div>
                </td>
            </tr></table>
        </td>
        <td class="right"><div class="title">PESANAN BELIAN</div><strong>No: <?php echo e($order->po_no); ?></strong><div>Tarikh: <?php echo e(\Carbon\Carbon::parse($order->po_date)->locale('ms')->translatedFormat('d F Y')); ?></div></td>
    </tr></table>
    <div class="rule"></div>
    <table class="addresses"><tr>
        <td>Kepada:<br><strong><?php echo e($order->company_name); ?></strong><div class="lines"><?php echo e($order->supplier_address); ?></div>U/P: <?php echo e($order->attention_supplier ?: '—'); ?><br>No. Tel: <?php echo e($order->supplier_phone ?: '—'); ?></td>
        <td>Alamat Penghantaran:<br><strong><?php echo e($document['delivery_company'] ?? config('purchase_order.issuer_name')); ?></strong><div class="lines"><?php echo e($order->delivery_address ?: config('purchase_order.issuer_address')); ?></div>U/P: <?php echo e($order->attention_delivery ?: config('purchase_order.delivery_attention')); ?><br>No. Tel: <?php echo e($document['delivery_phone'] ?? config('purchase_order.issuer_phone')); ?></td>
    </tr></table>
    <table class="items">
        <thead><tr><th width="5%">BIL</th><th width="42%">PERIHAL BARANGAN (ITEM DESCRIPTION)</th><th width="9%">KUANTITI</th><th width="10%">UNIT</th><th width="16%">HARGA SEUNIT<br>(RM)</th><th width="18%">JUMLAH<br>(RM)</th></tr></thead>
        <tbody><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td class="center"><?php echo e($loop->iteration); ?></td><td class="lines"><?php echo e($item->item_description); ?></td><td class="center"><?php echo e($item->quantity); ?></td><td class="center"><?php echo e($item->unit); ?></td><td class="right"><?php echo e(number_format($item->unit_price,2)); ?></td><td class="right"><?php echo e(number_format($item->subtotal,2)); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tbody>
    </table>
    <table class="totals"><tr><td class="right">JUMLAH KASAR:</td><td width="18%" class="right"><?php echo e(number_format($order->gross_amount,2)); ?></td></tr><tr><td class="right">DISKAUN PUKAL (<?php echo e((float)$order->discount_percent); ?>%):</td><td class="right"><?php echo e(number_format($order->discount_amount,2)); ?></td></tr><tr><td class="right">SST (<?php echo e((float)$order->sst_percent); ?>%):</td><td class="right"><?php echo e(number_format($order->sst_amount,2)); ?></td></tr><tr><td class="right">JUMLAH BERSIH:</td><td class="right net"><?php echo e(number_format($order->net_amount,2)); ?></td></tr></table>
    <div class="terms"><h3>TERMA &amp; SYARAT PEMBELIAN (TERMS &amp; CONDITIONS):</h3><div class="lines"><?php echo e(trim(preg_replace('/^\s*\d+\.\s*$/m', '', (string) $order->terms_conditions))); ?></div></div>
        <table class="signatures"><tr><td><strong>Disediakan Oleh:</strong><div class="signature">
            <?php if($order->prepared_by): ?><?php echo e($order->prepared_by); ?><br><?php endif; ?>
            <?php if(!empty($document['prepared_role'])): ?><?php echo e($document['prepared_role']); ?><?php endif; ?>
        </div></td><td><strong>Diluluskan Oleh:</strong><div class="signature">
            <?php if($order->approved_by): ?><?php echo e($order->approved_by); ?><br><?php endif; ?>
            <?php if(!empty($document['approved_role'])): ?><?php echo e($document['approved_role']); ?><?php endif; ?>
        </div></td></tr></table>
</body>
</html>
<?php /**PATH C:\laragon\www\sebutharga\resources\views\pages\purchase-order\pdf.blade.php ENDPATH**/ ?>