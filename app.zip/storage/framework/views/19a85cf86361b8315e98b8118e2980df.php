<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginald07245451647f5715f9bac44fc38d4f4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald07245451647f5715f9bac44fc38d4f4 = $attributes; } ?>
<?php $component = App\View\Components\Common\PageBreadcrumb::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.page-breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Common\PageBreadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageTitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Sebut Harga Pembekal'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald07245451647f5715f9bac44fc38d4f4)): ?>
<?php $attributes = $__attributesOriginald07245451647f5715f9bac44fc38d4f4; ?>
<?php unset($__attributesOriginald07245451647f5715f9bac44fc38d4f4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald07245451647f5715f9bac44fc38d4f4)): ?>
<?php $component = $__componentOriginald07245451647f5715f9bac44fc38d4f4; ?>
<?php unset($__componentOriginald07245451647f5715f9bac44fc38d4f4); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal6e5626e553feb0bf161f21170a535399 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6e5626e553feb0bf161f21170a535399 = $attributes; } ?>
<?php $component = App\View\Components\Common\ComponentCard::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.component-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Common\ComponentCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Senarai Sebut Harga Pembekal')),'x-data' => '{ filters: { search: \'\' }, matches(row) { const search = this.filters.search.toLowerCase(); return !search || row.number.toLowerCase().includes(search) || row.company.toLowerCase().includes(search) || row.title.toLowerCase().includes(search) || row.person.toLowerCase().includes(search); }, resetFilters() { this.filters = { search: \'\' }; } }']); ?>
    <div class="overflow-hidden rounded-2xl border border-gray-200 bg-white pt-4 dark:border-white/[0.05] dark:bg-white/[0.03]">
        <div class="mb-4 flex items-center gap-2 px-6">
            <div class="flex min-w-0 flex-1 flex-wrap items-center gap-2 rounded-xl border border-gray-200 bg-gray-50 p-1.5 dark:border-gray-700 dark:bg-gray-900/50">
                <input x-model="filters.search" type="search" placeholder="Cari no. sebut harga, syarikat atau PIC" aria-label="Cari no. sebut harga pembekal, syarikat, tajuk atau PIC" class="h-11 min-w-40 flex-1 rounded-lg border-0 bg-white px-3 text-theme-sm text-gray-700 shadow-theme-xs focus:ring-2 focus:ring-brand-500/20 dark:bg-gray-800 dark:text-gray-300">
            </div>
            <div class="contents">
                <button type="button" @click="resetFilters()" class="inline-flex h-11 items-center justify-center rounded-lg border border-gray-300 bg-white px-4 text-theme-sm font-medium text-gray-700 shadow-theme-xs hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400">See all</button>
                <a href="<?php echo e(route('sebut-harga-pembekal.create')); ?>" class="inline-flex h-11 items-center justify-center rounded-lg bg-brand-500 px-4 text-theme-sm font-medium text-white transition hover:bg-brand-600"><?php echo e(__('+ Tambah Sebut Harga Pembekal')); ?></a>
            </div>
        </div>
        <div class="max-w-full overflow-x-auto custom-scrollbar"><table class="w-full min-w-[850px] text-theme-sm leading-6 text-gray-700 dark:text-gray-300">
            <thead class="border-y border-gray-100 bg-gray-50 dark:border-white/[0.05] dark:bg-gray-900"><tr><?php $__currentLoopData = ['No. Sebut Harga', 'Pembekal', 'Tajuk', 'Sumber', 'Person In Charge', 'Tindakan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heading): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><th class="px-6 py-3 <?php echo e($heading === 'Tindakan' ? 'text-center' : 'text-start'); ?> text-theme-sm font-semibold text-gray-500 dark:text-gray-400"><?php echo e(__($heading)); ?></th><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tr></thead>
            <tbody><?php $__empty_1 = true; $__currentLoopData = $quotations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quotation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr x-show="matches({ number: <?php echo \Illuminate\Support\Js::from($quotation->quotation_no_supplier ?? '')->toHtml() ?>, company: <?php echo \Illuminate\Support\Js::from($quotation->company_name ?? '')->toHtml() ?>, title: <?php echo \Illuminate\Support\Js::from($quotation->quotation_title ?? '')->toHtml() ?>, person: <?php echo \Illuminate\Support\Js::from($quotation->person_in_charge ?? '')->toHtml() ?> })" class="border-b border-gray-100 hover:bg-gray-50 dark:border-white/[0.05] dark:hover:bg-white/[0.03]">
                <td class="px-4 py-3.5 text-gray-700 sm:px-6 dark:text-gray-400"><?php echo e($quotation->quotation_no_supplier); ?></td><td class="px-4 py-3.5 text-gray-800 sm:px-6 dark:text-white/90"><?php echo e($quotation->company_name); ?></td><td class="px-4 py-3.5 text-gray-700 sm:px-6 dark:text-gray-400"><?php echo e($quotation->quotation_title ?: '—'); ?></td><td class="px-4 py-3.5 text-gray-700 sm:px-6 dark:text-gray-400"><?php echo e($quotation->sumber_sebut_harga ?: '—'); ?></td><td class="px-4 py-3.5 text-gray-700 sm:px-6 dark:text-gray-400"><?php echo e($quotation->person_in_charge ?: '—'); ?></td><td class="px-4 py-3.5 text-center sm:px-6"><div class="flex items-center justify-center gap-2"><a href="<?php echo e(route('sebut-harga-pembekal.edit', $quotation->supplier_quotation_id)); ?>" class="inline-flex items-center rounded-lg border border-gray-200 px-3 py-1.5 text-xs font-medium text-gray-600 transition hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-white/[0.05]"><?php echo e(__('Lihat')); ?></a><form method="POST" action="<?php echo e(route('sebut-harga-pembekal.delete', $quotation->supplier_quotation_id)); ?>" @submit.prevent="$dispatch('confirm-action', { form: $el, message: 'Padam rekod ini?' })"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="inline-flex items-center justify-center rounded-lg border border-error-200 p-2 text-error-600 transition hover:bg-error-50 dark:border-error-700 dark:text-error-400 dark:hover:bg-error-500/10" title="<?php echo e(__('Padam')); ?>"><svg class="h-4 w-4 stroke-current" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M6 7h12m-9 0V5h6v2m-7 0 1 13h6l1-13M10 11v5m4-5v5"/></svg></button></form></div></td>
            </tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="6" class="px-6 py-12 text-center text-gray-500 dark:text-gray-400"><?php echo e(__('Tiada rekod untuk dipaparkan.')); ?></td></tr><?php endif; ?></tbody>
        </table></div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6e5626e553feb0bf161f21170a535399)): ?>
<?php $attributes = $__attributesOriginal6e5626e553feb0bf161f21170a535399; ?>
<?php unset($__attributesOriginal6e5626e553feb0bf161f21170a535399); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6e5626e553feb0bf161f21170a535399)): ?>
<?php $component = $__componentOriginal6e5626e553feb0bf161f21170a535399; ?>
<?php unset($__componentOriginal6e5626e553feb0bf161f21170a535399); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sebutharga\resources\views\pages\sebut-harga-pembekal\index.blade.php ENDPATH**/ ?>