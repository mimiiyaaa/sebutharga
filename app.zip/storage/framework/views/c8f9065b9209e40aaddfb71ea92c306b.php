<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginald07245451647f5715f9bac44fc38d4f4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald07245451647f5715f9bac44fc38d4f4 = $attributes; } ?>
<?php $component = App\View\Components\Common\PageBreadcrumb::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.page-breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Common\PageBreadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageTitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Maklumat Login'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald07245451647f5715f9bac44fc38d4f4)): ?>
<?php $attributes = $__attributesOriginald07245451647f5715f9bac44fc38d4f4; ?>
<?php unset($__attributesOriginald07245451647f5715f9bac44fc38d4f4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald07245451647f5715f9bac44fc38d4f4)): ?>
<?php $component = $__componentOriginald07245451647f5715f9bac44fc38d4f4; ?>
<?php unset($__componentOriginald07245451647f5715f9bac44fc38d4f4); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal6e5626e553feb0bf161f21170a535399 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6e5626e553feb0bf161f21170a535399 = $attributes; } ?>
<?php $component = App\View\Components\Common\ComponentCard::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.component-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Common\ComponentCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Senarai Pengguna'))]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <a href="<?php echo e(route('maklumat-login.create')); ?>" class="inline-flex h-11 items-center rounded-lg bg-brand-500 px-4 text-sm font-medium text-white transition hover:bg-brand-600">
            + <?php echo e(__('Tambah Pengguna')); ?>

        </a>
     <?php $__env->endSlot(); ?>
    <div class="overflow-x-auto custom-scrollbar"><table class="w-full min-w-[950px]"><thead><tr class="border-b border-gray-100 dark:border-gray-800"><?php $__currentLoopData = ['Nama', 'Jawatan', 'No. Kad Pengenalan', 'E-mel', 'Tarikh Daftar', 'Tindakan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heading): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><th class="px-5 py-3 text-start text-theme-xs font-medium text-gray-500 dark:text-gray-400"><?php echo e(__($heading)); ?></th><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tr></thead><tbody>
        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="border-b border-gray-100 dark:border-gray-800"><td class="px-5 py-4 font-medium text-gray-800 text-theme-sm dark:text-white/90"><?php echo e($user->name); ?></td><td class="px-5 py-4 text-gray-500 text-theme-sm dark:text-gray-400"><?php echo e($user->jawatan ?: '—'); ?></td><td class="px-5 py-4 text-gray-500 text-theme-sm dark:text-gray-400"><?php echo e($user->no_kp ?: '—'); ?></td><td class="px-5 py-4 text-gray-500 text-theme-sm dark:text-gray-400"><?php echo e($user->email); ?></td><td class="px-5 py-4 text-gray-500 text-theme-sm dark:text-gray-400"><?php echo e($user->created_at ? date('d/m/Y', strtotime($user->created_at)) : '—'); ?></td><td class="whitespace-nowrap px-5 py-4"><div class="flex items-center gap-2"><a href="<?php echo e(route('maklumat-login.edit', $user->id)); ?>" class="rounded-lg bg-brand-500 px-3 py-1.5 text-xs font-medium text-white"><?php echo e(__('Edit')); ?></a><form method="POST" action="<?php echo e(route('maklumat-login.delete', $user->id)); ?>" @submit.prevent="$dispatch('confirm-action', { form: $el, message: 'Padam pengguna ini?' })"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button type="submit" class="rounded-lg border border-error-200 p-2 text-error-600 dark:border-error-700 dark:text-error-400" title="<?php echo e(__('Padam')); ?>" aria-label="<?php echo e(__('Padam')); ?>">🗑</button></form></div></td></tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="6" class="px-5 py-10 text-center text-gray-500 dark:text-gray-400"><?php echo e(__('Tiada pengguna berdaftar.')); ?></td></tr>
        <?php endif; ?>
    </tbody></table></div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6e5626e553feb0bf161f21170a535399)): ?>
<?php $attributes = $__attributesOriginal6e5626e553feb0bf161f21170a535399; ?>
<?php unset($__attributesOriginal6e5626e553feb0bf161f21170a535399); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6e5626e553feb0bf161f21170a535399)): ?>
<?php $component = $__componentOriginal6e5626e553feb0bf161f21170a535399; ?>
<?php unset($__componentOriginal6e5626e553feb0bf161f21170a535399); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sebutharga\resources\views/pages/maklumat-login/index.blade.php ENDPATH**/ ?>