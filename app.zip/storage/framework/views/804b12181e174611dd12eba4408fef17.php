<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal497ae120098e047e8d383e0db08b547c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal497ae120098e047e8d383e0db08b547c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.common.document-workspace','data' => ['title' => __('Tambah Purchase Order'),'subtitle' => __('Lengkapkan maklumat pembekal, penghantaran dan item pesanan.')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.document-workspace'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Tambah Purchase Order')),'subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Lengkapkan maklumat pembekal, penghantaran dan item pesanan.'))]); ?>
     <?php $__env->slot('referenceActions', null, []); ?> <a href="<?php echo e(route('purchase-order.index')); ?>" class="inline-flex h-11 items-center justify-center rounded-lg border border-gray-300 bg-white px-4 text-sm font-medium text-gray-700 transition hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 dark:hover:bg-gray-800"><?php echo e(__('Kembali')); ?></a> <?php $__env->endSlot(); ?>
    <?php if (isset($component)) { $__componentOriginal8f0c3750a19f5b09bc170470eeecdb65 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8f0c3750a19f5b09bc170470eeecdb65 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.purchase-order.create-form','data' => ['suppliers' => $suppliers,'companies' => $companies,'quotation' => $quotation,'nextPoNo' => $nextPoNo,'initialItems' => $initialItems,'showBack' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('purchase-order.create-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['suppliers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($suppliers),'companies' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($companies),'quotation' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($quotation),'nextPoNo' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($nextPoNo),'initial-items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($initialItems),'show-back' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8f0c3750a19f5b09bc170470eeecdb65)): ?>
<?php $attributes = $__attributesOriginal8f0c3750a19f5b09bc170470eeecdb65; ?>
<?php unset($__attributesOriginal8f0c3750a19f5b09bc170470eeecdb65); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8f0c3750a19f5b09bc170470eeecdb65)): ?>
<?php $component = $__componentOriginal8f0c3750a19f5b09bc170470eeecdb65; ?>
<?php unset($__componentOriginal8f0c3750a19f5b09bc170470eeecdb65); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal497ae120098e047e8d383e0db08b547c)): ?>
<?php $attributes = $__attributesOriginal497ae120098e047e8d383e0db08b547c; ?>
<?php unset($__attributesOriginal497ae120098e047e8d383e0db08b547c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal497ae120098e047e8d383e0db08b547c)): ?>
<?php $component = $__componentOriginal497ae120098e047e8d383e0db08b547c; ?>
<?php unset($__componentOriginal497ae120098e047e8d383e0db08b547c); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sebutharga\resources\views\pages\purchase-order\create.blade.php ENDPATH**/ ?>