<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal497ae120098e047e8d383e0db08b547c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal497ae120098e047e8d383e0db08b547c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.common.document-workspace','data' => ['title' => __('Tambah Sebut Harga'),'subtitle' => __('Lengkapkan maklumat pelanggan, item dan terma dokumen.')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.document-workspace'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Tambah Sebut Harga')),'subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Lengkapkan maklumat pelanggan, item dan terma dokumen.'))]); ?>
         <?php $__env->slot('referenceActions', null, []); ?> 
            <a href="<?php echo e(route('sebut-harga')); ?>" class="inline-flex h-10 items-center justify-center rounded-lg border border-gray-300 bg-white px-4 text-sm font-medium text-gray-700 transition hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 dark:hover:bg-gray-800"><?php echo e(__('Kembali')); ?></a>
         <?php $__env->endSlot(); ?>
        <?php if (isset($component)) { $__componentOriginal46559536898d9637b12868dd6120954e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal46559536898d9637b12868dd6120954e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sebut-harga.create-form','data' => ['customers' => $customers,'companies' => $companies,'supplierQuotations' => $supplierQuotations,'quotation' => $sourceQuotation,'draft' => $sourceDraft,'editing' => $sourceDraft !== null,'copyAsNewQuotation' => $sourceDraft !== null,'showBack' => false,'jawatanOptions' => $jawatanOptions ?? collect()]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sebut-harga.create-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['customers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($customers),'companies' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($companies),'supplier-quotations' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($supplierQuotations),'quotation' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sourceQuotation),'draft' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sourceDraft),'editing' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sourceDraft !== null),'copy-as-new-quotation' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sourceDraft !== null),'show-back' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'jawatan-options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($jawatanOptions ?? collect())]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal46559536898d9637b12868dd6120954e)): ?>
<?php $attributes = $__attributesOriginal46559536898d9637b12868dd6120954e; ?>
<?php unset($__attributesOriginal46559536898d9637b12868dd6120954e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal46559536898d9637b12868dd6120954e)): ?>
<?php $component = $__componentOriginal46559536898d9637b12868dd6120954e; ?>
<?php unset($__componentOriginal46559536898d9637b12868dd6120954e); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal497ae120098e047e8d383e0db08b547c)): ?>
<?php $attributes = $__attributesOriginal497ae120098e047e8d383e0db08b547c; ?>
<?php unset($__attributesOriginal497ae120098e047e8d383e0db08b547c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal497ae120098e047e8d383e0db08b547c)): ?>
<?php $component = $__componentOriginal497ae120098e047e8d383e0db08b547c; ?>
<?php unset($__componentOriginal497ae120098e047e8d383e0db08b547c); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sebutharga\resources\views\pages\sebut-harga\create.blade.php ENDPATH**/ ?>