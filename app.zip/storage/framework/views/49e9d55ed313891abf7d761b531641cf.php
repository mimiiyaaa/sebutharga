<?php $__env->startSection('content'); ?>
  <p class="mb-5 text-3xl font-semibold tracking-tight text-gray-800 dark:text-white/90"><?php echo e(__('Dashboard')); ?></p>

  <div class="grid grid-cols-12 items-start gap-5 md:gap-6">
    <div class="col-span-12 space-y-5 xl:col-span-8">
    <section class="relative isolate h-[300px] overflow-visible rounded-3xl border border-gray-200 bg-white px-6 py-8 shadow-theme-xs dark:border-gray-800 dark:bg-gray-900 sm:px-10">
      <div class="grid h-full grid-cols-1 sm:grid-cols-[minmax(0,1fr)_350px]">
        <div class="relative z-10 self-center">
          <h1 class="mt-3 text-3xl font-semibold tracking-tight text-gray-900 dark:text-white/90 sm:text-4xl">
            <?php echo e(__('Selamat datang kembali')); ?>,<br>
            <span class="text-brand-600 dark:text-brand-400"><?php echo e(auth()->user()?->name ?? __('Pengguna')); ?>!</span>
          </h1>
          <p class="mt-4 max-w-md text-sm leading-6 text-gray-600 dark:text-gray-300">
            <?php echo e(__('Semak ringkasan sebut harga dan urus rekod syarikat anda di sini.')); ?>

          </p>
        </div>
        <div class="relative hidden sm:block">
          <img src="<?php echo e(asset('images/dashboard-mascot.png')); ?>" alt="<?php echo e(__('Maskot dashboard')); ?>" class="pointer-events-none absolute bottom-[-50px] end-0 z-20 h-[380px] w-[380px] max-w-none object-contain drop-shadow-sm" />
        </div>
      </div>
    </section>

    <div class="col-span-12">
      <?php if (isset($component)) { $__componentOriginalc07b2e1699f32a6c6657e13682549915 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc07b2e1699f32a6c6657e13682549915 = $attributes; } ?>
<?php $component = App\View\Components\Ecommerce\EcommerceMetrics::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ecommerce.ecommerce-metrics'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Ecommerce\EcommerceMetrics::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc07b2e1699f32a6c6657e13682549915)): ?>
<?php $attributes = $__attributesOriginalc07b2e1699f32a6c6657e13682549915; ?>
<?php unset($__attributesOriginalc07b2e1699f32a6c6657e13682549915); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc07b2e1699f32a6c6657e13682549915)): ?>
<?php $component = $__componentOriginalc07b2e1699f32a6c6657e13682549915; ?>
<?php unset($__componentOriginalc07b2e1699f32a6c6657e13682549915); ?>
<?php endif; ?>
    </div>

    <div class="col-span-12 xl:col-span-7">
      <?php if (isset($component)) { $__componentOriginal88262a36dd278cc0728546fcd85257bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal88262a36dd278cc0728546fcd85257bc = $attributes; } ?>
<?php $component = App\View\Components\Ecommerce\MonthlySale::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ecommerce.monthly-sale'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Ecommerce\MonthlySale::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal88262a36dd278cc0728546fcd85257bc)): ?>
<?php $attributes = $__attributesOriginal88262a36dd278cc0728546fcd85257bc; ?>
<?php unset($__attributesOriginal88262a36dd278cc0728546fcd85257bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal88262a36dd278cc0728546fcd85257bc)): ?>
<?php $component = $__componentOriginal88262a36dd278cc0728546fcd85257bc; ?>
<?php unset($__componentOriginal88262a36dd278cc0728546fcd85257bc); ?>
<?php endif; ?>
    </div>

    </div>

    <div class="col-span-12 space-y-5 xl:col-span-4">
      <?php if (isset($component)) { $__componentOriginalff4232d15220e4e44d6d3b5813985d2d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff4232d15220e4e44d6d3b5813985d2d = $attributes; } ?>
<?php $component = App\View\Components\Ecommerce\MonthlyTarget::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ecommerce.monthly-target'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Ecommerce\MonthlyTarget::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff4232d15220e4e44d6d3b5813985d2d)): ?>
<?php $attributes = $__attributesOriginalff4232d15220e4e44d6d3b5813985d2d; ?>
<?php unset($__attributesOriginalff4232d15220e4e44d6d3b5813985d2d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff4232d15220e4e44d6d3b5813985d2d)): ?>
<?php $component = $__componentOriginalff4232d15220e4e44d6d3b5813985d2d; ?>
<?php unset($__componentOriginalff4232d15220e4e44d6d3b5813985d2d); ?>
<?php endif; ?>
      <?php if (isset($component)) { $__componentOriginal0c2c061c9ec27aa8f67571fa33d51cc9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0c2c061c9ec27aa8f67571fa33d51cc9 = $attributes; } ?>
<?php $component = App\View\Components\Ecommerce\CustomerDemographic::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ecommerce.customer-demographic'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Ecommerce\CustomerDemographic::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0c2c061c9ec27aa8f67571fa33d51cc9)): ?>
<?php $attributes = $__attributesOriginal0c2c061c9ec27aa8f67571fa33d51cc9; ?>
<?php unset($__attributesOriginal0c2c061c9ec27aa8f67571fa33d51cc9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c2c061c9ec27aa8f67571fa33d51cc9)): ?>
<?php $component = $__componentOriginal0c2c061c9ec27aa8f67571fa33d51cc9; ?>
<?php unset($__componentOriginal0c2c061c9ec27aa8f67571fa33d51cc9); ?>
<?php endif; ?>
    </div>

    <div class="col-span-12">
      <?php if (isset($component)) { $__componentOriginal136890e789f0e924cbac157c7abdf091 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal136890e789f0e924cbac157c7abdf091 = $attributes; } ?>
<?php $component = App\View\Components\Ecommerce\StatisticsChart::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ecommerce.statistics-chart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Ecommerce\StatisticsChart::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal136890e789f0e924cbac157c7abdf091)): ?>
<?php $attributes = $__attributesOriginal136890e789f0e924cbac157c7abdf091; ?>
<?php unset($__attributesOriginal136890e789f0e924cbac157c7abdf091); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal136890e789f0e924cbac157c7abdf091)): ?>
<?php $component = $__componentOriginal136890e789f0e924cbac157c7abdf091; ?>
<?php unset($__componentOriginal136890e789f0e924cbac157c7abdf091); ?>
<?php endif; ?>
    </div>

    <div class="col-span-12">
      <?php if (isset($component)) { $__componentOriginal720eae9a29a663836f8ffb5d1f075923 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal720eae9a29a663836f8ffb5d1f075923 = $attributes; } ?>
<?php $component = App\View\Components\Ecommerce\RecentOrders::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ecommerce.recent-orders'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Ecommerce\RecentOrders::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal720eae9a29a663836f8ffb5d1f075923)): ?>
<?php $attributes = $__attributesOriginal720eae9a29a663836f8ffb5d1f075923; ?>
<?php unset($__attributesOriginal720eae9a29a663836f8ffb5d1f075923); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal720eae9a29a663836f8ffb5d1f075923)): ?>
<?php $component = $__componentOriginal720eae9a29a663836f8ffb5d1f075923; ?>
<?php unset($__componentOriginal720eae9a29a663836f8ffb5d1f075923); ?>
<?php endif; ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sebutharga\resources\views\pages\dashboard\ecommerce.blade.php ENDPATH**/ ?>