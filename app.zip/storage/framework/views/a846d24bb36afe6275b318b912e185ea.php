

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal82006bd10f973cb41165ac443372d112 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal82006bd10f973cb41165ac443372d112 = $attributes; } ?>
<?php $component = App\View\Components\Tables\BasicTables\BasicTablesThree::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tables.basic-tables.basic-tables-three'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Tables\BasicTables\BasicTablesThree::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal82006bd10f973cb41165ac443372d112)): ?>
<?php $attributes = $__attributesOriginal82006bd10f973cb41165ac443372d112; ?>
<?php unset($__attributesOriginal82006bd10f973cb41165ac443372d112); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal82006bd10f973cb41165ac443372d112)): ?>
<?php $component = $__componentOriginal82006bd10f973cb41165ac443372d112; ?>
<?php unset($__componentOriginal82006bd10f973cb41165ac443372d112); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sebutharga\resources\views\pages\invoice.blade.php ENDPATH**/ ?>