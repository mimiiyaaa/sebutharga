<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['suppliers' => collect(), 'companies' => collect(), 'quotation', 'nextPoNo', 'order' => null, 'initialItems' => [], 'returnToDetail' => false, 'showBack' => true]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['suppliers' => collect(), 'companies' => collect(), 'quotation', 'nextPoNo', 'order' => null, 'initialItems' => [], 'returnToDetail' => false, 'showBack' => true]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $inputClass = 'w-full min-h-11 rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-sm text-gray-800 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90';
    $labelClass = 'mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-400';
    $documentData = $order?->document_data ? (json_decode($order->document_data, true) ?: []) : [];
    $savedIssuerCompanyId = $companies->firstWhere('nama_syarikat', $documentData['issuer_name'] ?? null)?->company_id ?? '';
    $savedDeliveryCompanyId = $companies->firstWhere('nama_syarikat', $documentData['delivery_company'] ?? null)?->company_id ?? '';
?>

<form method="POST" action="<?php echo e($order ? route('purchase-order.update', $order->purchase_order_id) : route('purchase-order.store')); ?>" class="space-y-6 rounded-3xl bg-brand-50/35 p-3 dark:bg-brand-500/5 sm:p-4" x-data="{
    suppliers: <?php echo e(Illuminate\Support\Js::from($suppliers)); ?>,
    supplierId: <?php echo e(Illuminate\Support\Js::from((string) old('customer_id', $order?->customer_id ?? ''))); ?>,
    supplier: {},
    companies: <?php echo e(Illuminate\Support\Js::from($companies)); ?>,
    companyId: <?php echo e(Illuminate\Support\Js::from((string) old('company_id', $savedIssuerCompanyId))); ?>,
    deliveryCompanyId: <?php echo e(Illuminate\Support\Js::from((string) old('delivery_company_id', $savedDeliveryCompanyId))); ?>,
    issuer: {
        name: <?php echo e(Illuminate\Support\Js::from(old('issuer_name', $documentData['issuer_name'] ?? ''))); ?>,
        phone: <?php echo e(Illuminate\Support\Js::from(old('issuer_phone', $documentData['issuer_phone'] ?? ''))); ?>,
        email: <?php echo e(Illuminate\Support\Js::from(old('issuer_email', $documentData['issuer_email'] ?? ''))); ?>,
        personInCharge: <?php echo e(Illuminate\Support\Js::from(old('issuer_person_in_charge', $documentData['issuer_person_in_charge'] ?? ''))); ?>,
        address: <?php echo e(Illuminate\Support\Js::from(old('issuer_address', $documentData['issuer_address'] ?? ''))); ?>,
    },
    attentionSupplier: <?php echo e(Illuminate\Support\Js::from(old('attention_supplier', $order?->attention_supplier ?? ''))); ?>,
    delivery: <?php echo e(Illuminate\Support\Js::from(['company_name' => old('delivery_company', $documentData['delivery_company'] ?? ''), 'address' => old('delivery_address', $order?->delivery_address ?? ''), 'phone_no' => old('delivery_phone', $documentData['delivery_phone'] ?? ''), 'attention' => old('attention_delivery', $order?->attention_delivery ?? '')])); ?>,
    init() { this.supplier = this.suppliers.find(row => String(row.customer_id) === this.supplierId) || {}; },
    get selectedCompany() { return this.companies.find(row => String(row.company_id) === String(this.companyId)); },
    selectCompany() {
        const company = this.selectedCompany;
        if (!company) return;
        this.issuer.name = company.nama_syarikat || '';
        this.issuer.phone = company.no_telefon || '';
        this.issuer.email = company.emel || '';
        this.issuer.personInCharge = company.person_in_charge || '';
        this.issuer.address = company.alamat_syarikat || '';
    },
    selectDeliveryCompany() {
        const company = this.companies.find(row => String(row.company_id) === String(this.deliveryCompanyId));
        if (!company) return;
        this.delivery.company_name = company.nama_syarikat || '';
        this.delivery.phone_no = company.no_telefon || '';
        this.delivery.address = company.alamat_syarikat || '';
    },
    selectSupplier() {
        this.supplier = this.suppliers.find(row => String(row.customer_id) === String(this.supplierId)) || {};
        this.attentionSupplier = this.supplier.customer_name || '';
    },
    nextId: <?php echo e(count($initialItems) + 2); ?>,
    items: <?php echo e(Illuminate\Support\Js::from($initialItems ?: [['id'=>1, 'description'=>'', 'quantity'=>1, 'unit'=>'', 'price'=>0]])); ?>,
    discount: <?php echo e(Illuminate\Support\Js::from(old('discount_percent', $order?->discount_percent ?? 0))); ?>,
    sst: <?php echo e(Illuminate\Support\Js::from(old('sst_percent', $order?->sst_percent ?? 0))); ?>,
    subtotal(item) { return Math.round(Math.max(0, Number(item.quantity) || 0) * Math.max(0, Number(item.price) || 0) * 100) / 100 },
    get gross() { return this.items.reduce((sum, item) => sum + this.subtotal(item), 0) },
    get discountAmount() { return Math.round(this.gross * Math.min(100, Math.max(0, Number(this.discount) || 0))) / 100 },
    get sstAmount() { return Math.round((this.gross - this.discountAmount) * Math.min(100, Math.max(0, Number(this.sst) || 0))) / 100 },
    get net() { return this.gross - this.discountAmount + this.sstAmount },
    money(value) { return new Intl.NumberFormat('en-MY', { style: 'currency', currency: 'MYR' }).format(value) },
    addItem() { this.items.push({ id: this.nextId++, description: '', quantity: 1, unit: '', price: 0 }) }
}">
    <?php echo csrf_field(); ?>
    <?php if($showBack): ?>
        <div class="flex justify-end"><a href="<?php echo e($order && $returnToDetail ? route('purchase-order.show', $order->purchase_order_id) : route('purchase-order.index')); ?>" class="inline-flex items-center justify-center rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-sm font-medium text-gray-700 transition hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 dark:hover:bg-gray-800"><?php echo e(__('Kembali')); ?></a></div>
    <?php endif; ?>
    <?php if($order): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
    <?php if($order && $returnToDetail): ?><input type="hidden" name="from" value="show"><?php endif; ?>
    <input type="hidden" name="quotation_id" value="<?php echo e($quotation->quotation_id); ?>">
    <input type="hidden" name="quotation_detail_id" value="<?php echo e($quotation->quotation_detail_id); ?>">
    <input type="hidden" name="items_json" :value="JSON.stringify(items)">
    <?php if($errors->any()): ?>
        <ul role="alert" class="rounded-lg bg-error-50 p-4 text-error-700 dark:bg-error-500/10 dark:text-error-400">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>

    <div class="grid grid-cols-1 gap-6 xl:grid-cols-2">
        <?php if (isset($component)) { $__componentOriginal6054fcb7c372d34a0111bcdc769744fa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6054fcb7c372d34a0111bcdc769744fa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.common.document-card','data' => ['title' => __('Maklumat Syarikat')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.document-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Maklumat Syarikat'))]); ?>
            <div>
                <label for="company_id" class="<?php echo e($labelClass); ?>"><?php echo e(__('Nama Syarikat')); ?></label>
                <select id="company_id" name="company_id" x-model="companyId" @change="selectCompany()" class="<?php echo e($inputClass); ?>">
                    <option value=""><?php echo e(__('Pilih syarikat')); ?></option>
                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($company->company_id); ?>"><?php echo e($company->nama_syarikat); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <input type="hidden" name="issuer_name" x-model="issuer.name">
            </div>
            <div>
                <label for="issuer_phone" class="<?php echo e($labelClass); ?>"><?php echo e(__('Nombor Telefon')); ?></label>
                <input id="issuer_phone" name="issuer_phone" x-model="issuer.phone" type="tel" class="<?php echo e($inputClass); ?>">
            </div>
            <div>
                <label for="issuer_email" class="<?php echo e($labelClass); ?>"><?php echo e(__('E-mel')); ?></label>
                <input id="issuer_email" name="issuer_email" x-model="issuer.email" type="email" class="<?php echo e($inputClass); ?>">
            </div>
            <div>
                <label for="issuer_person_in_charge" class="<?php echo e($labelClass); ?>"><?php echo e(__('Person In Charge')); ?></label>
                <input id="issuer_person_in_charge" name="issuer_person_in_charge" x-model="issuer.personInCharge" class="<?php echo e($inputClass); ?>">
            </div>
            <div>
                <label for="issuer_address" class="<?php echo e($labelClass); ?>"><?php echo e(__('Alamat Syarikat')); ?></label>
                <textarea id="issuer_address" name="issuer_address" rows="3" x-model="issuer.address" class="<?php echo e($inputClass); ?> h-auto"></textarea>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6054fcb7c372d34a0111bcdc769744fa)): ?>
<?php $attributes = $__attributesOriginal6054fcb7c372d34a0111bcdc769744fa; ?>
<?php unset($__attributesOriginal6054fcb7c372d34a0111bcdc769744fa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6054fcb7c372d34a0111bcdc769744fa)): ?>
<?php $component = $__componentOriginal6054fcb7c372d34a0111bcdc769744fa; ?>
<?php unset($__componentOriginal6054fcb7c372d34a0111bcdc769744fa); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal6054fcb7c372d34a0111bcdc769744fa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6054fcb7c372d34a0111bcdc769744fa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.common.document-card','data' => ['title' => __('Maklumat PO')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.document-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Maklumat PO'))]); ?>
            <div>
                <label for="po_no" class="<?php echo e($labelClass); ?>"><?php echo e(__('No. PO')); ?></label>
                <input id="po_no" readonly value="<?php echo e($nextPoNo); ?>" class="<?php echo e($inputClass); ?>">
            </div>
            <div>
                <label for="po_date" class="<?php echo e($labelClass); ?>"><?php echo e(__('Tarikh PO')); ?></label>
                <input id="po_date" name="po_date" type="date" value="<?php echo e(old('po_date', $order?->po_date ?? now()->format('Y-m-d'))); ?>" required class="<?php echo e($inputClass); ?>">
            </div>
<input type="hidden" name="quotation_id" value="<?php echo e($quotation->quotation_id); ?>">
<input type="hidden" name="quotation_detail_id" value="<?php echo e($quotation->quotation_detail_id); ?>">
            <div>
                <label for="lo_inden_id" class="<?php echo e($labelClass); ?>"><?php echo e(__('LO / Inden (pilihan)')); ?></label>
                <select id="lo_inden_id" disabled class="<?php echo e($inputClass); ?>">
                    <option><?php echo e(__('Pilihan LO / Inden belum tersedia')); ?></option>
                </select>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6054fcb7c372d34a0111bcdc769744fa)): ?>
<?php $attributes = $__attributesOriginal6054fcb7c372d34a0111bcdc769744fa; ?>
<?php unset($__attributesOriginal6054fcb7c372d34a0111bcdc769744fa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6054fcb7c372d34a0111bcdc769744fa)): ?>
<?php $component = $__componentOriginal6054fcb7c372d34a0111bcdc769744fa; ?>
<?php unset($__componentOriginal6054fcb7c372d34a0111bcdc769744fa); ?>
<?php endif; ?>

    </div>

    <div class="grid grid-cols-1 gap-6 xl:grid-cols-2">
        <?php if (isset($component)) { $__componentOriginal6054fcb7c372d34a0111bcdc769744fa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6054fcb7c372d34a0111bcdc769744fa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.common.document-card','data' => ['title' => __('Kepada: Pembekal')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.document-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Kepada: Pembekal'))]); ?>
            <div>
                <label for="customer_id" class="<?php echo e($labelClass); ?>"><?php echo e(__('Pilih Pembekal')); ?></label>
                <select id="customer_id" name="customer_id" x-model="supplierId" @change="selectSupplier()" required class="<?php echo e($inputClass); ?>">
                    <option value=""><?php echo e(__('Sila pilih pembekal')); ?></option>
                    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($supplier->customer_id); ?>"><?php echo e($supplier->company_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($suppliers->isEmpty()): ?>
                    <p class="mt-2 text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('Tiada pembekal berdaftar.')); ?></p>
                <?php endif; ?>
            </div>
            <?php $__currentLoopData = ['attention_supplier' => 'Untuk Perhatian Pembekal', 'company_name' => 'Nama Pembekal / Syarikat', 'phone_no' => 'Nombor Telefon', 'email' => 'E-mel', 'reference_no' => 'No. Rujukan Pembekal']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <label for="<?php echo e($field); ?>" class="<?php echo e($labelClass); ?>"><?php echo e(__($label)); ?></label>
                    <input id="<?php echo e($field); ?>" name="<?php echo e($field); ?>" type="<?php echo e($field === 'email' ? 'email' : ($field === 'phone_no' ? 'tel' : 'text')); ?>"
                        <?php if($field !== 'attention_supplier'): ?> readonly :value="supplier.<?php echo e($field); ?> || ''" <?php else: ?> x-model="attentionSupplier" <?php endif; ?>
                        class="<?php echo e($inputClass); ?>">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div>
                <label for="supplier_address" class="<?php echo e($labelClass); ?>"><?php echo e(__('Alamat Pembekal')); ?></label>
                <textarea id="supplier_address" name="supplier_address" rows="3" readonly :value="supplier.address || ''" class="<?php echo e($inputClass); ?>"></textarea>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6054fcb7c372d34a0111bcdc769744fa)): ?>
<?php $attributes = $__attributesOriginal6054fcb7c372d34a0111bcdc769744fa; ?>
<?php unset($__attributesOriginal6054fcb7c372d34a0111bcdc769744fa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6054fcb7c372d34a0111bcdc769744fa)): ?>
<?php $component = $__componentOriginal6054fcb7c372d34a0111bcdc769744fa; ?>
<?php unset($__componentOriginal6054fcb7c372d34a0111bcdc769744fa); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal6054fcb7c372d34a0111bcdc769744fa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6054fcb7c372d34a0111bcdc769744fa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.common.document-card','data' => ['title' => __('Maklumat Penghantaran')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.document-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Maklumat Penghantaran'))]); ?>
        <div>
            <label for="delivery_company" class="<?php echo e($labelClass); ?>"><?php echo e(__('Nama Syarikat Penghantar')); ?></label>
            <select id="delivery_company_id" name="delivery_company_id" x-model="deliveryCompanyId" @change="selectDeliveryCompany()" class="<?php echo e($inputClass); ?>">
                <option value=""><?php echo e(__('Pilih syarikat penghantar')); ?></option>
                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($company->company_id); ?>"><?php echo e($company->nama_syarikat); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <input type="hidden" id="delivery_company" name="delivery_company" x-model="delivery.company_name">
        </div>
        <div>
            <label for="delivery_phone" class="<?php echo e($labelClass); ?>"><?php echo e(__('Nombor Telefon Penghantar')); ?></label>
            <input id="delivery_phone" name="delivery_phone" type="tel" x-model="delivery.phone_no" class="<?php echo e($inputClass); ?>">
        </div>
        <div>
            <label for="delivery_address" class="<?php echo e($labelClass); ?>"><?php echo e(__('Alamat Penghantaran')); ?></label>
            <textarea id="delivery_address" name="delivery_address" rows="3" x-model="delivery.address" class="<?php echo e($inputClass); ?>"></textarea>
        </div>
        <div class="grid grid-cols-1 gap-5 sm:grid-cols-2">
            <?php $__currentLoopData = ['attention_delivery' => 'Untuk Perhatian Penghantar']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <label for="<?php echo e($field); ?>" class="<?php echo e($labelClass); ?>"><?php echo e(__($label)); ?></label>
                    <input id="<?php echo e($field); ?>" name="<?php echo e($field); ?>" x-model="delivery.attention" class="<?php echo e($inputClass); ?>">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6054fcb7c372d34a0111bcdc769744fa)): ?>
<?php $attributes = $__attributesOriginal6054fcb7c372d34a0111bcdc769744fa; ?>
<?php unset($__attributesOriginal6054fcb7c372d34a0111bcdc769744fa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6054fcb7c372d34a0111bcdc769744fa)): ?>
<?php $component = $__componentOriginal6054fcb7c372d34a0111bcdc769744fa; ?>
<?php unset($__componentOriginal6054fcb7c372d34a0111bcdc769744fa); ?>
<?php endif; ?>
    </div>

    <?php if (isset($component)) { $__componentOriginal6054fcb7c372d34a0111bcdc769744fa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6054fcb7c372d34a0111bcdc769744fa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.common.document-card','data' => ['title' => __('Item PO')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.document-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Item PO'))]); ?>
        <div class="overflow-x-auto">
            <table class="w-full min-w-[900px] text-start text-theme-sm text-gray-700 dark:text-gray-300">
                <thead class="bg-error-800 text-white dark:bg-error-900 dark:text-white">
                    <tr>
                        <?php $__currentLoopData = ['Bil.', 'Keterangan / Description', 'Kuantiti', 'Unit', 'Harga Seunit (RM)', 'Jumlah (RM)', 'Tindakan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heading): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th scope="col" class="whitespace-nowrap px-3 py-3 text-start text-theme-xs font-semibold"><?php echo e(__($heading)); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody>
                    <template x-for="(item, index) in items" :key="item.id">
                        <tr class="border-b border-gray-100 dark:border-gray-800">
                            <td class="p-3 text-center tabular-nums" x-text="index + 1"></td>
                            <td class="min-w-60 p-3"><textarea rows="3" required x-model="item.description" aria-label="<?php echo e(__('Keterangan / Description')); ?>" placeholder="<?php echo e(__('Nama item / perkhidmatan')); ?>" class="<?php echo e($inputClass); ?>"></textarea></td>
                            <td class="min-w-32 p-3"><input type="number" min="1" step="1" required x-model.number="item.quantity" aria-label="<?php echo e(__('Kuantiti')); ?>" class="<?php echo e($inputClass); ?> text-center"></td>
                            <td class="min-w-32 p-3"><input required x-model="item.unit" aria-label="<?php echo e(__('Unit')); ?>" placeholder="<?php echo e(__('Unit')); ?>" class="<?php echo e($inputClass); ?> text-center"></td>
                            <td class="min-w-40 p-3"><input type="number" min="0" step="0.01" required x-model.number="item.price" aria-label="<?php echo e(__('Harga Seunit (RM)')); ?>" class="<?php echo e($inputClass); ?> price-input text-end"></td>
                            <td class="whitespace-nowrap p-3" x-text="money(subtotal(item))"></td>
                            <td class="p-3"><button type="button" @click="items.splice(index, 1)" :disabled="items.length === 1" class="text-error-600 disabled:cursor-not-allowed disabled:opacity-40 dark:text-error-400"><?php echo e(__('Buang')); ?></button></td>
                        </tr>
                    </template>
                </tbody>
            </table>
        </div>
        <button type="button" @click="addItem()" class="rounded-lg border border-brand-300 px-4 py-2 text-sm font-medium text-brand-600 hover:bg-brand-50 dark:border-brand-700 dark:text-brand-400 dark:hover:bg-brand-500/10"><?php echo e(__('+ Tambah Item')); ?></button>
        <div class="ms-auto max-w-sm space-y-4 text-sm text-gray-700 dark:text-gray-300" aria-live="polite">
            <div class="flex justify-between gap-4"><span><?php echo e(__('Jumlah Kasar')); ?></span><span x-text="money(gross)"></span></div>
            <div class="flex items-center justify-between gap-4">
                <label for="discount_percent"><?php echo e(__('Diskaun (%)')); ?></label>
                <div class="w-32"><input id="discount_percent" name="discount_percent" type="number" min="0" max="100" step="0.01" x-model.number="discount" class="<?php echo e($inputClass); ?>"></div>
            </div>
            <div class="flex justify-between gap-4"><span><?php echo e(__('Jumlah Diskaun')); ?></span><span x-text="money(discountAmount)"></span></div>
            <div class="flex items-center justify-between gap-4">
                <label for="sst_percent"><?php echo e(__('SST (%)')); ?></label>
                <div class="w-32"><input id="sst_percent" name="sst_percent" type="number" min="0" max="100" step="0.01" x-model.number="sst" class="<?php echo e($inputClass); ?>"></div>
            </div>
            <div class="flex justify-between gap-4"><span><?php echo e(__('Jumlah SST')); ?></span><span x-text="money(sstAmount)"></span></div>
            <div class="flex justify-between gap-4 border-t border-gray-200 pt-4 text-lg font-semibold dark:border-gray-700"><span><?php echo e(__('Jumlah Bersih')); ?></span><span x-text="money(net)"></span></div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6054fcb7c372d34a0111bcdc769744fa)): ?>
<?php $attributes = $__attributesOriginal6054fcb7c372d34a0111bcdc769744fa; ?>
<?php unset($__attributesOriginal6054fcb7c372d34a0111bcdc769744fa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6054fcb7c372d34a0111bcdc769744fa)): ?>
<?php $component = $__componentOriginal6054fcb7c372d34a0111bcdc769744fa; ?>
<?php unset($__componentOriginal6054fcb7c372d34a0111bcdc769744fa); ?>
<?php endif; ?>

    <?php
        $storedTerms = old('terms_conditions', $order?->terms_conditions ?? config('purchase_order.terms'));
        preg_match('/tempoh\s+(\d+)\s+hari bekerja/i', $storedTerms, $deliveryMatch);
        preg_match('/tempoh\s+(\d+)\s+hari\s+\(Kredit\)/i', $storedTerms, $paymentMatch);
        $additionalTerms = implode("\n", array_slice(preg_split('/\r?\n/', $storedTerms), 4));
    ?>
    <?php if (isset($component)) { $__componentOriginal6054fcb7c372d34a0111bcdc769744fa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6054fcb7c372d34a0111bcdc769744fa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.common.document-card','data' => ['title' => __('Terma dan Syarat Pembelian'),'xData' => '{ periods: { delivery: '.e(old('delivery_days', $deliveryMatch[1] ?? 14)).', payment: '.e(old('payment_days', $paymentMatch[1] ?? 30)).' }, insertNextTerm(event) { const field = event.target; const before = field.value.slice(0, field.selectionStart); const after = field.value.slice(field.selectionEnd); const nextNumber = 5 + before.split(/\r?\n/).filter(Boolean).length; const insertion = `\n${nextNumber}. `; field.value = before + insertion + after; field.dispatchEvent(new Event(\'input\', { bubbles: true })); requestAnimationFrame(() => { const cursor = before.length + insertion.length; field.setSelectionRange(cursor, cursor); }); } }']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.document-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Terma dan Syarat Pembelian')),'x-data' => '{ periods: { delivery: '.e(old('delivery_days', $deliveryMatch[1] ?? 14)).', payment: '.e(old('payment_days', $paymentMatch[1] ?? 30)).' }, insertNextTerm(event) { const field = event.target; const before = field.value.slice(0, field.selectionStart); const after = field.value.slice(field.selectionEnd); const nextNumber = 5 + before.split(/\r?\n/).filter(Boolean).length; const insertion = `\n${nextNumber}. `; field.value = before + insertion + after; field.dispatchEvent(new Event(\'input\', { bubbles: true })); requestAnimationFrame(() => { const cursor = before.length + insertion.length; field.setSelectionRange(cursor, cursor); }); } }']); ?>
        <div class="grid grid-cols-1 gap-5 sm:grid-cols-2">
            <div><label for="delivery_days" class="<?php echo e($labelClass); ?>"><?php echo e(__('Tempoh Penghantaran (Hari)')); ?></label><input id="delivery_days" name="delivery_days" type="number" min="1" max="3650" required x-model="periods.delivery" class="<?php echo e($inputClass); ?>"></div>
            <div><label for="payment_days" class="<?php echo e($labelClass); ?>"><?php echo e(__('Tempoh Pembayaran (Hari)')); ?></label><input id="payment_days" name="payment_days" type="number" min="1" max="3650" required x-model="periods.payment" class="<?php echo e($inputClass); ?>"></div>
        </div>
        <p class="text-sm text-gray-600 dark:text-gray-300"><?php echo e(__('Tempoh penghantaran dan pembayaran dikira dari tarikh PO dikeluarkan serta pengesahan penerimaan dokumen.')); ?></p>
        <div class="space-y-2 text-sm leading-6 text-gray-700 dark:text-gray-300">
            <p>1. <?php echo e(__('Sila nyatakan nombor Purchase Order (PO) ini di dalam Invois dan Nota Serahan (DO) rasmi anda.')); ?></p>
            <p>2. <?php echo e(__('Penghantaran mestilah menepati spesifikasi teknikal yang dipesan. Barangan rosak/salah akan dipulangkan.')); ?></p>
            <p>3. <?php echo e(__('Sila hantar bekalan dalam tempoh')); ?> <span class="font-semibold" x-text="periods.delivery || '—'"></span> <?php echo e(__('hari bekerja dari tarikh dokumen ini dikeluarkan.')); ?></p>
            <p>4. <?php echo e(__('Pembayaran penuh akan diproses dalam tempoh')); ?> <span class="font-semibold" x-text="periods.payment || '—'"></span> <?php echo e(__('hari (Kredit) selepas pengesahan penerimaan DO & Invois.')); ?></p>
        </div>
        <div><label for="additional_terms" class="<?php echo e($labelClass); ?>"><?php echo e(__('Terma Tambahan')); ?></label><textarea id="additional_terms" name="additional_terms" rows="4" maxlength="10000" @keydown.enter.prevent="insertNextTerm($event)" class="<?php echo e($inputClass); ?>"><?php echo e(old('additional_terms', $additionalTerms)); ?></textarea><p class="mt-2 text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('Tekan Enter untuk sambung nombor terma secara automatik bermula daripada 5.')); ?></p></div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6054fcb7c372d34a0111bcdc769744fa)): ?>
<?php $attributes = $__attributesOriginal6054fcb7c372d34a0111bcdc769744fa; ?>
<?php unset($__attributesOriginal6054fcb7c372d34a0111bcdc769744fa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6054fcb7c372d34a0111bcdc769744fa)): ?>
<?php $component = $__componentOriginal6054fcb7c372d34a0111bcdc769744fa; ?>
<?php unset($__componentOriginal6054fcb7c372d34a0111bcdc769744fa); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal6054fcb7c372d34a0111bcdc769744fa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6054fcb7c372d34a0111bcdc769744fa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.common.document-card','data' => ['title' => __('Pengesahan PO')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.document-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Pengesahan PO'))]); ?>
        <div class="grid grid-cols-1 gap-6 md:grid-cols-2">
            <div class="flex flex-col rounded-xl border border-gray-200 bg-gray-50/50 p-5 dark:border-gray-700 dark:bg-gray-800/30 sm:p-6">
                <div class="space-y-5">
                    <div>
                        <label for="prepared_by" class="<?php echo e($labelClass); ?>"><?php echo e(__('Disediakan Oleh')); ?></label>
                        <input id="prepared_by" name="prepared_by" value="<?php echo e(old('prepared_by', $order?->prepared_by ?? auth()->user()?->name)); ?>" class="<?php echo e($inputClass); ?>">
                    </div>
                    <div>
                        <label for="prepared_role" class="<?php echo e($labelClass); ?>"><?php echo e(__('Jawatan / Unit Penyedia')); ?></label>
                        <input id="prepared_role" name="prepared_role" value="<?php echo e(old('prepared_role', $order?->prepared_role ?? config('purchase_order.prepared_role'))); ?>" class="<?php echo e($inputClass); ?>">
                    </div>
                </div>
                <div class="h-16" aria-hidden="true"></div>
                <div class="min-h-16 border-t border-dashed border-gray-400 pt-3 text-sm text-gray-500 dark:border-gray-600 dark:text-gray-400"><?php echo e(__('Ruang Tandatangan')); ?></div>
            </div>
            <div class="flex flex-col rounded-xl border border-gray-200 bg-gray-50/50 p-5 dark:border-gray-700 dark:bg-gray-800/30 sm:p-6">
                <div class="space-y-5">
                    <div>
                        <label for="approved_by" class="<?php echo e($labelClass); ?>"><?php echo e(__('Diluluskan Oleh')); ?></label>
                        <input id="approved_by" name="approved_by" value="<?php echo e(old('approved_by', $order?->approved_by)); ?>" class="<?php echo e($inputClass); ?>">
                    </div>
                    <div>
                        <label for="approved_role" class="<?php echo e($labelClass); ?>"><?php echo e(__('Jawatan Pelulus')); ?></label>
                        <input id="approved_role" name="approved_role" value="<?php echo e(old('approved_role', $order?->approved_role ?? config('purchase_order.approved_role'))); ?>" class="<?php echo e($inputClass); ?>">
                    </div>
                </div>
                <div class="h-16" aria-hidden="true"></div>
                <div class="min-h-16 border-t border-dashed border-gray-400 pt-3 text-sm text-gray-500 dark:border-gray-600 dark:text-gray-400"><?php echo e(__('Ruang Tandatangan')); ?></div>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6054fcb7c372d34a0111bcdc769744fa)): ?>
<?php $attributes = $__attributesOriginal6054fcb7c372d34a0111bcdc769744fa; ?>
<?php unset($__attributesOriginal6054fcb7c372d34a0111bcdc769744fa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6054fcb7c372d34a0111bcdc769744fa)): ?>
<?php $component = $__componentOriginal6054fcb7c372d34a0111bcdc769744fa; ?>
<?php unset($__componentOriginal6054fcb7c372d34a0111bcdc769744fa); ?>
<?php endif; ?>
    <div class="flex flex-wrap items-center justify-end gap-3">
        <button type="submit" class="inline-flex items-center justify-center rounded-lg bg-brand-500 px-5 py-2.5 text-sm font-medium text-white hover:bg-brand-600 dark:bg-brand-500 dark:text-white"><?php echo e(__('Simpan PO')); ?></button>
    </div>
</form>
<?php /**PATH C:\laragon\www\sebutharga\resources\views/components/purchase-order/create-form.blade.php ENDPATH**/ ?>