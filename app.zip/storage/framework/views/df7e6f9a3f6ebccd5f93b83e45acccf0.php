<?php $__env->startSection('content'); ?>

    <?php
        $isFinalView = request('from') === 'final';
        $linkedLo = $linkedLo ?? null;
    ?>
    <?php if (isset($component)) { $__componentOriginal497ae120098e047e8d383e0db08b547c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal497ae120098e047e8d383e0db08b547c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.common.document-workspace','data' => ['title' => __('Butiran Sebut Harga'),'subtitle' => $quotation->quotation_no,'reference' => ($isFinalView ? __('Versi') . ' ' . ($draft->final_no ?? $draft->draft_no) : __('Draf') . ' ' . $draft->draft_no),'xData' => '{ editing: '.e(request('edit') ? 'true' : 'false').', editMode: \'existing\', loginInfoOpen: false, sendModalOpen: false }','@keydown.escape.window' => 'loginInfoOpen = false; sendModalOpen = false']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.document-workspace'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Butiran Sebut Harga')),'subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($quotation->quotation_no),'reference' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(($isFinalView ? __('Versi') . ' ' . ($draft->final_no ?? $draft->draft_no) : __('Draf') . ' ' . $draft->draft_no)),'x-data' => '{ editing: '.e(request('edit') ? 'true' : 'false').', editMode: \'existing\', loginInfoOpen: false, sendModalOpen: false }','@keydown.escape.window' => 'loginInfoOpen = false; sendModalOpen = false']); ?>
     <?php $__env->slot('referenceActions', null, []); ?> <a x-show="!editing" x-cloak href="<?php echo e(request('from') === 'final' ? route('sebut-harga.final', ['draft' => $draft->quotation_detail_id]) : route('sebut-harga')); ?>" class="inline-flex h-9 items-center justify-center rounded-lg border border-gray-200 bg-white px-3 text-theme-xs font-medium text-gray-600 transition hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700"><?php echo e(__('Kembali')); ?></a><div class="relative" @click.outside="loginInfoOpen = false"><button type="button" @click="loginInfoOpen = !loginInfoOpen" title="<?php echo e(__('Maklumat Login')); ?>" aria-label="<?php echo e(__('Maklumat Login')); ?>" class="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-gray-200 bg-white text-gray-600 transition hover:border-brand-300 hover:text-brand-600 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 dark:hover:border-brand-700 dark:hover:text-brand-400"><svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M12 16v-4m0-4h.01M21 12a9 9 1 1-18 0 9 9 0 0 1 18 0Z"/></svg></button><?php if (isset($component)) { $__componentOriginal138969a60b1852068eba0fb28ea7dddf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal138969a60b1852068eba0fb28ea7dddf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.common.created-by-panel','data' => ['name' => $createdBy?->name,'jawatan' => $createdBy?->jawatan,'email' => $createdBy?->email,'createdAt' => $draft->created_at,'documentLabel' => 'draf ini']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.created-by-panel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($createdBy?->name),'jawatan' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($createdBy?->jawatan),'email' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($createdBy?->email),'created-at' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($draft->created_at),'document-label' => 'draf ini']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal138969a60b1852068eba0fb28ea7dddf)): ?>
<?php $attributes = $__attributesOriginal138969a60b1852068eba0fb28ea7dddf; ?>
<?php unset($__attributesOriginal138969a60b1852068eba0fb28ea7dddf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal138969a60b1852068eba0fb28ea7dddf)): ?>
<?php $component = $__componentOriginal138969a60b1852068eba0fb28ea7dddf; ?>
<?php unset($__componentOriginal138969a60b1852068eba0fb28ea7dddf); ?>
<?php endif; ?></div> <?php $__env->endSlot(); ?>
    <div>
        <?php
            $document = App\Helpers\QuotationDocument::data($draft);
            $value = fn (string $field, $fallback = null) => filled($document[$field] ?? null) ? $document[$field] : ($fallback ?? '—');
            $issuer = [
                'Nama Syarikat' => $value('issuer_name', $quotation->nama_syarikat),
                'Nombor Telefon' => $value('issuer_phone', $quotation->no_telefon),
                'E-mel' => $value('issuer_email', $quotation->emel),
                'Person In Charge' => $value('issuer_person_in_charge', $quotation->person_in_charge),
                'Alamat Syarikat' => $value('issuer_address', $quotation->alamat_syarikat),
            ];
            $recipient = [
                'Nama Pelanggan' => $value('customer_name', $quotation->customer_name),
                'Nama Syarikat' => $value('company_name', $quotation->company_name),
                'Nombor Telefon' => $value('phone_no', $quotation->phone_no),
                'E-mel' => $value('email', $quotation->email),
                'Alamat' => $value('address', $quotation->address),
            ];
        ?>
        <div x-show="!editing" x-cloak class="mb-6 overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-theme-sm dark:border-gray-800 dark:bg-white/[0.03]">
            <div class="border-b border-gray-200 bg-gray-50 px-6 py-7 dark:border-gray-800 dark:bg-gray-900 sm:px-8">
                <div class="flex w-full flex-wrap items-center justify-between gap-4">
                    <div class="min-w-0">
                        <p class="text-xs font-semibold uppercase tracking-[0.18em] text-brand-600 dark:text-brand-400"><?php echo e(__('Maklumat Utama')); ?></p>
                        <h3 class="mt-2 truncate text-3xl font-semibold tracking-tight text-gray-900 dark:text-white/90"><?php echo e($quotation->quotation_no); ?></h3>
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400"><?php echo e($quotation->company_name ?: $quotation->customer_name ?: __('Tiada pelanggan')); ?> · <?php echo e(__('Ringkasan sebut harga')); ?></p>
                    </div>
                    <div class="flex shrink-0 flex-wrap items-center justify-end gap-1.5 rounded-xl border border-gray-200 bg-gray-50 p-1.5 dark:border-gray-700 dark:bg-gray-900/60">
                        <a href="<?php echo e(route('sebut-harga.preview', [$quotation->quotation_id, 'draft' => $draft->quotation_detail_id, 'from' => request('from') === 'final' ? 'final' : 'draft', 'via' => 'detail'])); ?>" class="inline-flex h-9 items-center gap-2 rounded-lg px-3 text-xs font-medium text-gray-600 transition hover:bg-white hover:text-gray-900 dark:text-gray-300 dark:hover:bg-gray-800 dark:hover:text-white"><svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z"/><circle cx="12" cy="12" r="2.5" stroke-width="1.8"/></svg><?php echo e(__('Pratonton')); ?></a>
                        <?php if(! $isFinalView): ?>
                            <button type="button" @click="editMode = 'existing'; editing = true" class="inline-flex h-9 items-center gap-2 rounded-lg px-3 text-xs font-medium text-gray-600 transition hover:bg-white hover:text-gray-900 dark:text-gray-300 dark:hover:bg-gray-800 dark:hover:text-white"><svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="m14 6 4 4M4 20l4.5-1 9.8-9.8a2.1 2.1 0 0 0-3-3L5.5 16 4 20Z"/></svg>Edit</button>
                            <button type="button" @click="editMode = 'new'; editing = true" class="inline-flex h-9 items-center gap-2 rounded-lg px-3 text-xs font-medium text-gray-600 transition hover:bg-white hover:text-gray-900 dark:text-gray-300 dark:hover:bg-gray-800 dark:hover:text-white"><svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M7 3h7l4 4v14H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Zm7 0v5h5M8 13h6m-6 4h6"/></svg><?php echo e(__('Draf Baharu')); ?></button>
                            <?php if(strtolower(trim((string) $draft->status_draft)) === 'final'): ?>
                                <span class="inline-flex h-10 items-center rounded-lg bg-success-50 px-3 text-sm font-medium text-success-700 dark:bg-success-500/15 dark:text-success-400"><?php echo e(__('Sudah Difinalisekan')); ?></span>
                            <?php else: ?>
                                <form class="inline-flex shrink-0" method="POST" action="<?php echo e(route('sebut-harga.draft.approve', [$quotation->quotation_id, $draft->quotation_detail_id])); ?>" @submit.prevent="$dispatch('confirm-action', { form: $el, message: 'Muktamadkan draf ini? Draf lain akan kekal sebagai draf.', button: 'Muktamadkan' })">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="inline-flex h-9 shrink-0 items-center gap-2 rounded-lg bg-brand-500 px-3 text-xs font-semibold text-white transition hover:bg-brand-600"><svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m5 12 4 4L19 6"/></svg><?php echo e(__('Muktamadkan')); ?></button>
                                </form>
                            <?php endif; ?>
                        <?php else: ?>
                            <form method="POST" action="<?php echo e(route('sebut-harga.final.new', [$quotation->quotation_id, $draft->quotation_detail_id])); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="inline-flex h-9 items-center rounded-lg px-3 text-xs font-medium text-brand-600 transition hover:bg-white dark:text-brand-400 dark:hover:bg-gray-800"><?php echo e(__('Cipta Versi Baharu')); ?></button>
                            </form>
                            <?php if(empty($draft->sent_at)): ?>
                                <button type="button" @click="sendModalOpen = true" class="inline-flex h-9 items-center rounded-lg bg-brand-500 px-3 text-xs font-semibold text-white transition hover:bg-brand-600"><?php echo e(__('Hantar')); ?></button>
                            <?php elseif($draft->status_quotation === null): ?>
                                <form method="POST" action="<?php echo e(route('sebut-harga.final.agree', [$quotation->quotation_id, $draft->quotation_detail_id])); ?>" @submit.prevent="$dispatch('confirm-action', { form: $el, message: 'Tandakan sebut harga ini sebagai berjaya?', button: 'Setuju' })">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="inline-flex h-9 items-center rounded-lg bg-success-500 px-3 text-xs font-semibold text-white transition hover:bg-success-600"><?php echo e(__('Setuju')); ?></button>
                                </form>
                                <span class="inline-flex h-9 items-center rounded-lg bg-peach-100 px-3 text-xs font-medium text-peach-700 dark:bg-peach-500/15 dark:text-peach-300"><?php echo e(__('Menunggu LO')); ?></span>
                                <form method="POST" action="<?php echo e(route('sebut-harga.final.undo-send', [$quotation->quotation_id, $draft->quotation_detail_id])); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="inline-flex h-9 items-center rounded-lg px-3 text-xs font-medium text-gray-600 transition hover:bg-white hover:text-gray-900 dark:text-gray-300 dark:hover:bg-gray-800 dark:hover:text-white"><?php echo e(__('Undo Hantar')); ?></button>
                                </form>
                            <?php else: ?>
                                <?php if((int) $draft->status_quotation === 1): ?>
                                    <?php if($linkedLo): ?>
                                        <a href="<?php echo e(route('lo.show', $linkedLo->lo_inden_id)); ?>" class="inline-flex h-9 items-center rounded-lg bg-success-50 px-3 text-xs font-medium text-success-700 transition hover:bg-success-100 dark:bg-success-500/15 dark:text-success-400 dark:hover:bg-success-500/25"><?php echo e(__('Berjaya — LO Diterima')); ?></a>
                                    <?php else: ?>
                                        <span class="inline-flex h-9 items-center rounded-lg bg-success-50 px-3 text-xs font-medium text-success-700 dark:bg-success-500/15 dark:text-success-400"><?php echo e(__('Berjaya — Belum Ada LO')); ?></span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="inline-flex h-9 items-center rounded-lg bg-error-50 px-3 text-xs font-medium text-error-700 dark:bg-error-500/15 dark:text-error-400"><?php echo e(__('Tidak Berjaya')); ?></span>
                                <?php endif; ?>
                                <form method="POST" action="<?php echo e(route('sebut-harga.final.undo-decision', [$quotation->quotation_id, $draft->quotation_detail_id])); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="inline-flex h-9 items-center rounded-lg px-3 text-xs font-medium text-gray-600 transition hover:bg-white hover:text-gray-900 dark:text-gray-300 dark:hover:bg-gray-800 dark:hover:text-white"><?php echo e(__('Undo Keputusan')); ?></button>
                                </form>
                            <?php endif; ?>
                            <span class="inline-flex h-9 items-center rounded-lg bg-success-50 px-3 text-xs font-medium text-success-700 dark:bg-success-500/15 dark:text-success-400"><?php echo e(__('Final')); ?> <?php echo e($draft->final_no ?? $draft->draft_no); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="grid grid-cols-1 gap-4 border-b border-gray-100 bg-gray-50/60 p-6 sm:grid-cols-2 dark:border-gray-800 dark:bg-gray-900/40">
                <div><p class="text-sm text-gray-500 dark:text-gray-400">No. Sebut Harga</p><p class="mt-2 text-base font-medium text-gray-800 dark:text-white/90"><?php echo e($quotation->quotation_no); ?></p></div>
                <div><p class="text-sm text-gray-500 dark:text-gray-400">Tarikh</p><p class="mt-2 text-base font-medium text-gray-800 dark:text-white/90"><?php echo e($quotation->quotation_date); ?></p></div>
                <div><p class="text-sm text-gray-500 dark:text-gray-400">Pelanggan / Syarikat</p><p class="mt-2 text-base font-medium text-gray-800 dark:text-white/90"><?php echo e($quotation->company_name ?: $quotation->customer_name); ?></p></div>
                <div><p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e($isFinalView ? __('Versi') : __('Draf')); ?></p><p class="mt-2 text-base font-medium text-gray-800 dark:text-white/90"><?php echo e($isFinalView ? __('Versi') . ' ' . ($draft->final_no ?? $draft->draft_no) : __('Draf') . ' ' . $draft->draft_no); ?></p></div>
                <div><p class="text-sm text-gray-500 dark:text-gray-400">Kemaskini Terakhir</p><p class="mt-2 text-base font-medium text-gray-800 dark:text-white/90"><?php echo e($draft->updated_at ? \Carbon\Carbon::parse($draft->updated_at)->format('d/m/Y H:i') : '-'); ?></p></div>
                <div><p class="text-sm text-gray-500 dark:text-gray-400">No. Rujukan Pelanggan</p><p class="mt-2 text-base font-medium text-gray-800 dark:text-white/90"><?php echo e($quotation->no_rujukan_pelanggan ?: '—'); ?></p></div>
                <div><p class="text-sm text-gray-500 dark:text-gray-400">Sumber Sebut Harga</p><p class="mt-2 text-base font-medium text-gray-800 dark:text-white/90"><?php echo e($draft->sumber_sebut_harga ?: '—'); ?></p></div>
                <?php if($draft->sent_at): ?>
                    <div><p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('Dihantar Oleh')); ?></p><p class="mt-2 text-base font-medium text-gray-800 dark:text-white/90"><?php echo e($draft->sent_by ?: '—'); ?></p></div>
                    <div><p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('Tarikh & Masa Hantar')); ?></p><p class="mt-2 text-base font-medium text-gray-800 dark:text-white/90"><?php echo e(\Carbon\Carbon::parse($draft->sent_at)->format('d/m/Y H:i')); ?></p></div>
                <?php endif; ?>
            </div>
            <div class="border-t border-gray-100 px-6 py-5 dark:border-gray-800"><p class="text-sm text-gray-500 dark:text-gray-400">Tajuk</p><p class="mt-2 text-base font-medium text-gray-800 dark:text-white/90"><?php echo e($quotation->quotation_title ?: '-'); ?></p></div>
            <div class="grid grid-cols-1 gap-5 border-t border-gray-100 p-6 dark:border-gray-800 lg:grid-cols-2">
                <?php $__currentLoopData = ['Maklumat Syarikat Pengeluar' => $issuer, 'Maklumat Pelanggan' => $recipient]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section => $fields): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <section class="border-t border-gray-200 pt-5 first:border-t-0 first:pt-0 dark:border-gray-800">
                        <h4 class="mb-5 text-base font-semibold text-gray-800 dark:text-white/90"><?php echo e(__($section)); ?></h4>
                        <div class="grid grid-cols-1 gap-5 sm:grid-cols-2">
                            <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $fieldValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(__($label)); ?></p>
                                    <p class="mt-2 whitespace-pre-line break-words text-base font-medium text-gray-800 dark:text-white/90"><?php echo e($fieldValue); ?></p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </section>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="grid grid-cols-1 gap-5 border-t border-gray-100 p-6 dark:border-gray-800 lg:grid-cols-2">
                <section class="border-t border-gray-200 pt-5 dark:border-gray-800 lg:border-t-0 lg:border-s lg:ps-6">
                    <h4 class="mb-3 text-base font-semibold text-gray-800 dark:text-white/90"><?php echo e(__('Terma dan Syarat')); ?></h4>
                    <p class="whitespace-pre-line text-base leading-6 text-gray-700 dark:text-gray-300"><?php echo e($draft->terma_syarat ?: '—'); ?></p>
                </section>
                <section class="border-t border-gray-200 pt-5 dark:border-gray-800 lg:border-t-0 lg:border-s lg:ps-6">
                    <h4 class="mb-3 text-base font-semibold text-gray-800 dark:text-white/90"><?php echo e(__('Pengesahan Sebut Harga')); ?></h4>
                    <div class="grid grid-cols-1 gap-5 sm:grid-cols-2">
                        <div><p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('Disediakan Oleh')); ?></p><p class="mt-2 text-base font-medium text-gray-800 dark:text-white/90"><?php echo e($draft->disediakan_oleh ?: '—'); ?></p></div>
                        <div><p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('Jawatan')); ?></p><p class="mt-2 text-base font-medium text-gray-800 dark:text-white/90"><?php echo e($value('disediakan_role', $draft->disediakan_role)); ?></p></div>
                        <div><p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('Nama Syarikat')); ?></p><p class="mt-2 text-base font-medium text-gray-800 dark:text-white/90"><?php echo e($value('disediakan_company_name', $quotation->nama_syarikat)); ?></p></div>
                        <div><p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('Diterima Oleh')); ?></p><p class="mt-2 text-base font-medium text-gray-800 dark:text-white/90"><?php echo e($draft->diterima_oleh ?: '—'); ?></p></div>
                    </div>
                </section>
            </div>
        
        <div x-show="!editing" x-cloak class="border-t border-gray-200 dark:border-gray-800">
            <div class="border-b border-gray-100 px-6 py-5 dark:border-gray-800">
                <h3 class="text-lg font-semibold text-gray-800 dark:text-white/90"><?php echo e(__('Maklumat Tambahan')); ?></h3>
                <p class="mt-1 text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('Maklumat dalaman ini dipaparkan dalam sistem sahaja dan tidak dimasukkan ke dalam PDF.')); ?></p>
            </div>
            <div class="grid grid-cols-1 gap-6 p-6 lg:grid-cols-2">
                <section>
                    <h4 class="mb-3 text-base font-semibold text-gray-800 dark:text-white/90"><?php echo e(__('Maklumat Tambahan')); ?></h4>
                    <p class="whitespace-pre-line break-words text-base leading-6 text-gray-700 dark:text-gray-300"><?php echo e(filled($document['maklumat_tambahan'] ?? null) ? $document['maklumat_tambahan'] : '—'); ?></p>
                </section>
                <section class="border-t border-gray-100 pt-6 dark:border-gray-800 lg:border-t-0 lg:border-s lg:ps-6 lg:pt-0">
                    <h4 class="mb-3 text-base font-semibold text-gray-800 dark:text-white/90"><?php echo e(__('Catatan')); ?></h4>
                    <p class="whitespace-pre-line break-words text-base leading-6 text-gray-700 dark:text-gray-300"><?php echo e(filled($document['catatan'] ?? null) ? $document['catatan'] : '—'); ?></p>
                </section>
            </div>
        </div>

        <div x-show="!editing" x-cloak class="border-t border-gray-200 dark:border-gray-800">
            <div class="flex items-center justify-between border-b border-gray-100 px-6 py-5 dark:border-gray-800">
                <div>
                    <h3 class="text-lg font-semibold text-gray-800 dark:text-white/90">Item Sebut Harga</h3>
                    <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">Maklumat draf ini dalam paparan terkunci</p>
                </div>
                <span class="rounded-full bg-peach-100 px-3 py-1 text-xs font-medium text-peach-700 dark:bg-peach-500/15 dark:text-peach-300"><?php echo e($isFinalView ? ($draft->status_draft ?: 'Final') : 'Draf'); ?></span>
            </div>
            <div class="custom-scrollbar overflow-x-auto px-4 pb-4">
                <table class="w-full min-w-[760px] overflow-hidden rounded-xl text-start text-theme-sm">
                    <thead class="bg-error-800 text-white dark:bg-error-900 dark:text-white">
                        <tr>
                            <th scope="col" class="w-14 px-5 py-4 text-center text-theme-xs font-semibold"><?php echo e(__('Bil')); ?></th>
                            <th scope="col" class="w-2/5 px-5 py-4 text-start text-theme-xs font-semibold">Perihal Barangan</th>
                            <th scope="col" class="px-5 py-4 text-center text-theme-xs font-semibold">Kuantiti</th>
                            <th scope="col" class="px-5 py-4 text-center text-theme-xs font-semibold">Unit</th>
                            <th scope="col" class="whitespace-nowrap px-5 py-4 text-end text-theme-xs font-semibold">Harga Seunit (RM)</th>
                            <th scope="col" class="whitespace-nowrap px-5 py-4 text-end text-theme-xs font-semibold">Jumlah (RM)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $draft->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="border-b border-gray-100 even:bg-gray-50/60 hover:bg-brand-50/40 dark:border-gray-800 dark:even:bg-gray-800/30 dark:hover:bg-brand-500/5">
                                <td class="px-5 py-5 text-center tabular-nums text-gray-400 dark:text-gray-500"><?php echo e($loop->iteration); ?></td>
                                <td class="px-5 py-5 font-medium leading-6 text-gray-800 dark:text-gray-200"><p class="whitespace-pre-line break-words"><?php echo e($item->item_description); ?></p></td>
                                <td class="whitespace-nowrap px-5 py-5 text-center tabular-nums text-gray-600 dark:text-gray-300"><?php echo e($item->quantity); ?></td>
                                <td class="whitespace-nowrap px-5 py-5 text-center tabular-nums text-gray-600 dark:text-gray-300"><?php echo e($item->unit); ?></td>
                                <td class="whitespace-nowrap px-5 py-5 text-end tabular-nums text-gray-600 dark:text-gray-300">RM <?php echo e(number_format((float) $item->unit_price, 2)); ?></td>
                                <td class="whitespace-nowrap px-5 py-5 text-end font-semibold tabular-nums text-gray-900 dark:text-white/90">RM <?php echo e(number_format((float) $item->subtotal, 2)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="6" class="px-3 py-6 text-center text-gray-500 dark:text-gray-400">Tiada item</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="flex justify-end border-t border-gray-100 bg-gray-50 p-6 dark:border-gray-800 dark:bg-gray-900">
                <div class="flex w-full flex-wrap items-center justify-between gap-4 rounded-xl border border-gray-200 bg-white px-5 py-4 text-gray-800 dark:border-gray-700 dark:bg-gray-800 dark:text-white/90 sm:w-auto sm:min-w-80">
                    <span class="text-theme-sm font-medium">Jumlah Total</span>
                    <span class="text-xl font-semibold tabular-nums">RM <?php echo e(number_format((float) $draft->jumlah_total, 2)); ?></span>
                </div>
            </div>
        </div>
        </div>

        <div x-show="editing && editMode === 'existing'" x-cloak class="space-y-6">
            <div class="flex items-center justify-between gap-4">
                <h2 class="text-lg font-semibold text-gray-800 dark:text-white/90"><?php echo e(__('Kemaskini Sebut Harga')); ?></h2>
                <button type="button" @click="editing = false" class="inline-flex h-11 items-center justify-center rounded-lg border border-gray-300 bg-white px-4 text-sm font-medium text-gray-700 transition hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 dark:hover:bg-gray-800"><?php echo e(__('Kembali')); ?></button>
            </div>
            <?php if (isset($component)) { $__componentOriginal46559536898d9637b12868dd6120954e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal46559536898d9637b12868dd6120954e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sebut-harga.create-form','data' => ['customers' => $customers,'companies' => $companies,'supplierQuotations' => $supplierQuotations,'quotation' => $quotation,'draft' => $draft,'editing' => true,'submitAtTop' => false,'showBack' => false,'updateDraft' => true,'jawatanOptions' => $jawatanOptions ?? collect()]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sebut-harga.create-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['customers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($customers),'companies' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($companies),'supplier-quotations' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($supplierQuotations),'quotation' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($quotation),'draft' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($draft),'editing' => true,'submit-at-top' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'show-back' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'update-draft' => true,'jawatan-options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($jawatanOptions ?? collect())]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal46559536898d9637b12868dd6120954e)): ?>
<?php $attributes = $__attributesOriginal46559536898d9637b12868dd6120954e; ?>
<?php unset($__attributesOriginal46559536898d9637b12868dd6120954e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal46559536898d9637b12868dd6120954e)): ?>
<?php $component = $__componentOriginal46559536898d9637b12868dd6120954e; ?>
<?php unset($__componentOriginal46559536898d9637b12868dd6120954e); ?>
<?php endif; ?>
        </div>
        <div x-show="editing && editMode === 'new'" x-cloak class="space-y-6">
            <div class="flex items-center justify-between gap-4">
                <h2 class="text-lg font-semibold text-gray-800 dark:text-white/90">Draf Baharu</h2>
                <button type="button" @click="editing = false" class="inline-flex h-11 items-center justify-center rounded-lg border border-gray-300 bg-white px-4 text-sm font-medium text-gray-700 transition hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 dark:hover:bg-gray-800"><?php echo e(__('Kembali')); ?></button>
            </div>
            <?php if (isset($component)) { $__componentOriginal46559536898d9637b12868dd6120954e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal46559536898d9637b12868dd6120954e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sebut-harga.create-form','data' => ['customers' => $customers,'companies' => $companies,'supplierQuotations' => $supplierQuotations,'quotation' => $quotation,'draft' => $draft,'editing' => true,'submitAtTop' => false,'showBack' => false,'jawatanOptions' => $jawatanOptions ?? collect()]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sebut-harga.create-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['customers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($customers),'companies' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($companies),'supplier-quotations' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($supplierQuotations),'quotation' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($quotation),'draft' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($draft),'editing' => true,'submit-at-top' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'show-back' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'jawatan-options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($jawatanOptions ?? collect())]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal46559536898d9637b12868dd6120954e)): ?>
<?php $attributes = $__attributesOriginal46559536898d9637b12868dd6120954e; ?>
<?php unset($__attributesOriginal46559536898d9637b12868dd6120954e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal46559536898d9637b12868dd6120954e)): ?>
<?php $component = $__componentOriginal46559536898d9637b12868dd6120954e; ?>
<?php unset($__componentOriginal46559536898d9637b12868dd6120954e); ?>
<?php endif; ?>
        </div>
    </div>
    <?php if($isFinalView && strtolower(trim((string) $draft->status_draft)) === 'final' && empty($draft->sent_at)): ?>
        <div x-cloak x-show="sendModalOpen" x-transition.opacity class="fixed inset-0 z-999999 flex items-center justify-center bg-gray-900/50 p-4" @click.self="sendModalOpen = false">
            <form method="POST" action="<?php echo e(route('sebut-harga.final.send', [$quotation->quotation_id, $draft->quotation_detail_id])); ?>" x-show="sendModalOpen" x-transition class="w-full max-w-md rounded-2xl bg-white shadow-theme-xl dark:bg-gray-900">
                <?php echo csrf_field(); ?>
                <div class="flex items-start justify-between gap-4 border-b border-gray-100 px-6 py-5 dark:border-gray-800"><div><h2 class="text-lg font-semibold text-gray-800 dark:text-white/90"><?php echo e(__('Maklumat Penghantaran')); ?></h2><p class="mt-1 text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('Lengkapkan maklumat sebelum menghantar sebut harga.')); ?></p></div><button type="button" @click="sendModalOpen = false" class="text-xl text-gray-500 hover:text-gray-800 dark:text-gray-400 dark:hover:text-white/90" aria-label="<?php echo e(__('Tutup')); ?>">&times;</button></div>
                <div class="space-y-4 px-6 py-5"><div><label for="sent_by" class="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-400"><?php echo e(__('Dihantar Oleh')); ?></label><input id="sent_by" name="sent_by" required value="<?php echo e(old('sent_by', auth()->user()?->name)); ?>" class="w-full min-h-11 rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-sm text-gray-800 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90"></div><div class="grid grid-cols-1 gap-4 sm:grid-cols-2"><div><label for="sent_date" class="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-400"><?php echo e(__('Tarikh Hantar')); ?></label><input id="sent_date" name="sent_date" type="text" inputmode="numeric" required value="<?php echo e(old('sent_date', now()->format('m/d/Y'))); ?>" placeholder="mm/dd/yyyy" class="w-full min-h-11 rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-sm text-gray-800 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90"></div><div><label for="sent_time" class="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-400"><?php echo e(__('Masa Hantar')); ?></label><input id="sent_time" name="sent_time" type="text" required value="<?php echo e(old('sent_time', now()->format('h:i A'))); ?>" placeholder="hh:mm AM/PM" class="w-full min-h-11 rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-sm text-gray-800 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90"></div></div></div>
                <div class="flex justify-end gap-3 border-t border-gray-100 px-6 py-4 dark:border-gray-800"><button type="button" @click="sendModalOpen = false" class="inline-flex h-10 items-center rounded-lg border border-gray-300 px-4 text-sm font-medium text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800"><?php echo e(__('Batal')); ?></button><button type="submit" class="inline-flex h-10 items-center rounded-lg bg-brand-500 px-4 text-sm font-medium text-white hover:bg-brand-600"><?php echo e(__('Hantar')); ?></button></div>
            </form>
        </div>
    <?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal497ae120098e047e8d383e0db08b547c)): ?>
<?php $attributes = $__attributesOriginal497ae120098e047e8d383e0db08b547c; ?>
<?php unset($__attributesOriginal497ae120098e047e8d383e0db08b547c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal497ae120098e047e8d383e0db08b547c)): ?>
<?php $component = $__componentOriginal497ae120098e047e8d383e0db08b547c; ?>
<?php unset($__componentOriginal497ae120098e047e8d383e0db08b547c); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sebutharga\resources\views\pages\sebut-harga\edit.blade.php ENDPATH**/ ?>