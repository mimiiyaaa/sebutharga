<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginald07245451647f5715f9bac44fc38d4f4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald07245451647f5715f9bac44fc38d4f4 = $attributes; } ?>
<?php $component = App\View\Components\Common\PageBreadcrumb::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.page-breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Common\PageBreadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageTitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Lihat Local Order'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald07245451647f5715f9bac44fc38d4f4)): ?>
<?php $attributes = $__attributesOriginald07245451647f5715f9bac44fc38d4f4; ?>
<?php unset($__attributesOriginald07245451647f5715f9bac44fc38d4f4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald07245451647f5715f9bac44fc38d4f4)): ?>
<?php $component = $__componentOriginald07245451647f5715f9bac44fc38d4f4; ?>
<?php unset($__componentOriginald07245451647f5715f9bac44fc38d4f4); ?>
<?php endif; ?>

    <?php
        $documentIsImage = in_array(strtolower(pathinfo((string) $lo->document_file, PATHINFO_EXTENSION)), ['jpg', 'jpeg', 'png'], true);
        $customerName = $lo->company_name ?: ($lo->customer_name ?: '—');
    ?>

    <div class="space-y-6">
        <div class="flex flex-col gap-4 rounded-2xl border border-gray-200 bg-white px-5 py-5 shadow-theme-xs dark:border-gray-800 dark:bg-gray-900 sm:flex-row sm:items-center sm:justify-between sm:px-6">
            <div>
                <div class="flex flex-wrap items-center gap-2">
                    <h1 class="text-xl font-semibold text-gray-800 dark:text-white/90"><?php echo e(__('Lihat Local Order')); ?></h1>
                    <span class="inline-flex items-center rounded-full bg-success-50 px-2.5 py-1 text-xs font-medium text-success-700 dark:bg-success-500/15 dark:text-success-400"><?php echo e(__('Berjaya')); ?></span>
                </div>
                <p class="mt-1 text-sm text-gray-500 dark:text-gray-400"><?php echo e($lo->lo_inden_no); ?></p>
            </div>
            <div class="flex flex-wrap gap-3">
                <a href="<?php echo e(route('lo')); ?>" class="inline-flex h-10 items-center justify-center rounded-lg border border-gray-300 bg-white px-4 text-sm font-medium text-gray-700 transition hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 dark:hover:bg-gray-800"><?php echo e(__('Kembali')); ?></a>
                <a href="<?php echo e(route('lo.edit', $lo->lo_inden_id)); ?>" class="inline-flex h-10 items-center justify-center rounded-lg bg-brand-500 px-4 text-sm font-medium text-white transition hover:bg-brand-600"><?php echo e(__('Edit Local Order')); ?></a>
            </div>
        </div>

        <?php if (isset($component)) { $__componentOriginal6054fcb7c372d34a0111bcdc769744fa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6054fcb7c372d34a0111bcdc769744fa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.common.document-card','data' => ['title' => __('Ringkasan Local Order'),'desc' => __('Maklumat utama dokumen ini.')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.document-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Ringkasan Local Order')),'desc' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Maklumat utama dokumen ini.'))]); ?>
            <div class="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
                <div class="rounded-xl bg-gray-50 p-4 dark:bg-gray-800/50">
                    <p class="text-xs font-medium uppercase tracking-wide text-gray-500 dark:text-gray-400"><?php echo e(__('No. Local Order')); ?></p>
                    <p class="mt-2 text-base font-semibold text-gray-800 dark:text-white/90"><?php echo e($lo->lo_inden_no); ?></p>
                </div>
                <div class="rounded-xl bg-gray-50 p-4 dark:bg-gray-800/50">
                    <p class="text-xs font-medium uppercase tracking-wide text-gray-500 dark:text-gray-400"><?php echo e(__('Pelanggan / Syarikat')); ?></p>
                    <p class="mt-2 text-base font-semibold text-gray-800 dark:text-white/90"><?php echo e($customerName); ?></p>
                </div>
                <div class="rounded-xl bg-gray-50 p-4 dark:bg-gray-800/50">
                    <p class="text-xs font-medium uppercase tracking-wide text-gray-500 dark:text-gray-400"><?php echo e(__('Tarikh Local Order')); ?></p>
                    <p class="mt-2 text-base font-semibold text-gray-800 dark:text-white/90"><?php echo e(\Carbon\Carbon::parse($lo->lo_inden_date)->format('d/m/Y')); ?></p>
                </div>
                <div class="rounded-xl bg-brand-50 p-4 dark:bg-brand-500/10">
                    <p class="text-xs font-medium uppercase tracking-wide text-brand-600 dark:text-brand-400"><?php echo e(__('Jumlah (RM)')); ?></p>
                    <p class="mt-2 text-base font-semibold tabular-nums text-brand-700 dark:text-brand-300">RM <?php echo e(number_format((float) $lo->amount, 2)); ?></p>
                </div>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6054fcb7c372d34a0111bcdc769744fa)): ?>
<?php $attributes = $__attributesOriginal6054fcb7c372d34a0111bcdc769744fa; ?>
<?php unset($__attributesOriginal6054fcb7c372d34a0111bcdc769744fa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6054fcb7c372d34a0111bcdc769744fa)): ?>
<?php $component = $__componentOriginal6054fcb7c372d34a0111bcdc769744fa; ?>
<?php unset($__componentOriginal6054fcb7c372d34a0111bcdc769744fa); ?>
<?php endif; ?>

        <?php if($lo->quotation_no): ?>
            <?php if (isset($component)) { $__componentOriginal6054fcb7c372d34a0111bcdc769744fa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6054fcb7c372d34a0111bcdc769744fa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.common.document-card','data' => ['title' => __('Sebut Harga Final'),'desc' => __('Rujukan sebut harga yang digunakan untuk Local Order ini.')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.document-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Sebut Harga Final')),'desc' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Rujukan sebut harga yang digunakan untuk Local Order ini.'))]); ?>
                <div class="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
                    <div>
                        <p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('No. Sebut Harga')); ?></p>
                        <p class="mt-1.5 font-semibold text-gray-800 dark:text-white/90"><?php echo e($lo->quotation_no); ?></p>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('Versi')); ?></p>
                        <p class="mt-1.5 font-semibold text-gray-800 dark:text-white/90"><?php echo e($lo->final_no); ?></p>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('Tarikh Sebut Harga')); ?></p>
                        <p class="mt-1.5 font-semibold text-gray-800 dark:text-white/90"><?php echo e($lo->quotation_date ? \Carbon\Carbon::parse($lo->quotation_date)->format('d/m/Y') : '—'); ?></p>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('Status')); ?></p>
                        <span class="mt-1.5 inline-flex rounded-full bg-success-50 px-2.5 py-1 text-xs font-medium text-success-700 dark:bg-success-500/15 dark:text-success-400"><?php echo e(__('Berjaya')); ?></span>
                    </div>
                    <div class="sm:col-span-2 lg:col-span-4">
                        <p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('Tajuk')); ?></p>
                        <p class="mt-1.5 font-semibold text-gray-800 dark:text-white/90"><?php echo e($lo->quotation_title ?: '—'); ?></p>
                    </div>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6054fcb7c372d34a0111bcdc769744fa)): ?>
<?php $attributes = $__attributesOriginal6054fcb7c372d34a0111bcdc769744fa; ?>
<?php unset($__attributesOriginal6054fcb7c372d34a0111bcdc769744fa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6054fcb7c372d34a0111bcdc769744fa)): ?>
<?php $component = $__componentOriginal6054fcb7c372d34a0111bcdc769744fa; ?>
<?php unset($__componentOriginal6054fcb7c372d34a0111bcdc769744fa); ?>
<?php endif; ?>
        <?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal6054fcb7c372d34a0111bcdc769744fa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6054fcb7c372d34a0111bcdc769744fa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.common.document-card','data' => ['title' => __('Dokumen Local Order'),'desc' => __('Pratonton dokumen yang telah dimuat naik.')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.document-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Dokumen Local Order')),'desc' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Pratonton dokumen yang telah dimuat naik.'))]); ?>
            <div class="overflow-hidden rounded-xl border border-gray-200 bg-gray-100 p-3 dark:border-gray-700 dark:bg-gray-950/40">
                <?php if($documentIsImage): ?>
                    <img src="<?php echo e(route('lo.document', $lo->lo_inden_id)); ?>" alt="<?php echo e(__('Dokumen Local Order')); ?>" class="mx-auto max-h-[720px] w-auto max-w-full rounded-lg object-contain">
                <?php else: ?>
                    <iframe src="<?php echo e(route('lo.document', $lo->lo_inden_id)); ?>" title="<?php echo e(__('Dokumen Local Order')); ?>" class="h-[720px] w-full rounded-lg border-0"></iframe>
                <?php endif; ?>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6054fcb7c372d34a0111bcdc769744fa)): ?>
<?php $attributes = $__attributesOriginal6054fcb7c372d34a0111bcdc769744fa; ?>
<?php unset($__attributesOriginal6054fcb7c372d34a0111bcdc769744fa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6054fcb7c372d34a0111bcdc769744fa)): ?>
<?php $component = $__componentOriginal6054fcb7c372d34a0111bcdc769744fa; ?>
<?php unset($__componentOriginal6054fcb7c372d34a0111bcdc769744fa); ?>
<?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sebutharga\resources\views\pages\lo\show.blade.php ENDPATH**/ ?>