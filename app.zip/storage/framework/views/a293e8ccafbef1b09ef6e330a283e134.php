<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['companies' => collect()]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['companies' => collect()]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<div class="overflow-x-auto custom-scrollbar">
    <table class="w-full min-w-[900px]"><thead><tr class="border-b border-gray-100 dark:border-gray-800">
        <?php $__currentLoopData = ['Nama Syarikat', 'No. Telefon', 'E-mel', 'Person In Charge', 'Alamat', 'Tindakan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heading): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><th class="px-5 py-3 text-start sm:px-6"><p class="font-medium text-gray-500 text-theme-xs dark:text-gray-400"><?php echo e(__($heading)); ?></p></th><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr></thead><tbody>
        <?php $__empty_1 = true; $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="border-b border-gray-100 dark:border-gray-800"><td class="px-5 py-4 text-gray-800 text-theme-sm dark:text-white/90"><?php echo e($company->nama_syarikat); ?></td><td class="px-5 py-4 text-gray-500 text-theme-sm dark:text-gray-400"><?php echo e($company->no_telefon ?: '—'); ?></td><td class="px-5 py-4 text-gray-500 text-theme-sm dark:text-gray-400"><?php echo e($company->emel ?: '—'); ?></td><td class="px-5 py-4 text-gray-500 text-theme-sm dark:text-gray-400"><?php echo e($company->person_in_charge ?: '—'); ?></td><td class="max-w-xs px-5 py-4 text-gray-500 text-theme-sm dark:text-gray-400"><?php echo e($company->alamat_syarikat ?: '—'); ?></td><td class="whitespace-nowrap px-5 py-4"><div class="flex items-center gap-2"><a href="<?php echo e(route('companies.show', $company->company_id)); ?>" class="inline-flex rounded-lg border border-gray-200 px-3 py-1.5 text-xs font-medium text-gray-600 dark:border-gray-700 dark:text-gray-300"><?php echo e(__('Lihat')); ?></a><a href="<?php echo e(route('companies.edit', $company->company_id)); ?>" class="inline-flex rounded-lg bg-brand-500 px-3 py-1.5 text-xs font-medium text-white"><?php echo e(__('Edit')); ?></a><form method="POST" action="<?php echo e(route('companies.delete', $company->company_id)); ?>" @submit.prevent="$dispatch('confirm-action', { form: $el, message: 'Padam rekod ini?' })"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button type="submit" class="inline-flex rounded-lg border border-error-200 p-2 text-error-600" title="<?php echo e(__('Padam')); ?>" aria-label="<?php echo e(__('Padam')); ?>">🗑</button></form></div></td></tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="6" class="px-5 py-10 text-center text-gray-500 text-theme-sm dark:text-gray-400"><?php echo e(__('Tiada rekod untuk dipaparkan.')); ?></td></tr>
        <?php endif; ?>
    </tbody></table>
</div>
<?php /**PATH C:\laragon\www\sebutharga\resources\views\components\tables\basic-tables\company-table.blade.php ENDPATH**/ ?>