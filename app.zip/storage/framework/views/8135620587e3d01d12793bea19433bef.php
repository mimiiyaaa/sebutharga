<?php $__env->startSection('content'); ?>
    <div class="mb-6 flex flex-wrap items-center justify-between gap-3">
        <h2 class="text-xl font-semibold text-gray-800 dark:text-white/90"><?php echo e($company ? __('Edit Syarikat') : __('Tambah Syarikat')); ?></h2>
        <a href="<?php echo e(route('syarikat')); ?>" class="inline-flex h-10 items-center justify-center rounded-lg border border-gray-300 bg-white px-4 text-sm font-medium text-gray-700 transition hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 dark:hover:bg-gray-800"><?php echo e(__('Kembali')); ?></a>
    </div>

    <div class="w-full">
        <form method="POST" action="<?php echo e(route('companies.save', ['id' => $company?->company_id])); ?>" enctype="multipart/form-data" class="space-y-6">
            <?php echo csrf_field(); ?>

            <?php if (isset($component)) { $__componentOriginal6054fcb7c372d34a0111bcdc769744fa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6054fcb7c372d34a0111bcdc769744fa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.common.document-card','data' => ['title' => $company ? __('Kemaskini Maklumat Syarikat') : __('Maklumat Syarikat'),'desc' => $company ? __('Kemaskini maklumat syarikat yang dipilih.') : __('Masukkan maklumat syarikat untuk digunakan dalam sebut harga.')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.document-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($company ? __('Kemaskini Maklumat Syarikat') : __('Maklumat Syarikat')),'desc' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($company ? __('Kemaskini maklumat syarikat yang dipilih.') : __('Masukkan maklumat syarikat untuk digunakan dalam sebut harga.'))]); ?>
                <div class="grid grid-cols-1 gap-5 md:grid-cols-2">
                    <div class="md:col-span-2">
                        <label for="nama_syarikat" class="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-300"><?php echo e(__('Nama Syarikat')); ?> <span class="text-error-500">*</span></label>
                        <input id="nama_syarikat" name="nama_syarikat" type="text" value="<?php echo e(old('nama_syarikat', $company?->nama_syarikat)); ?>" placeholder="Contoh: ABC Holdings Sdn. Bhd." required class="min-h-11 w-full rounded-xl border border-gray-200 bg-gray-50/70 px-4 py-2.5 text-sm text-gray-800 outline-none transition placeholder:text-gray-400 focus:border-brand-500 focus:bg-white focus:ring-2 focus:ring-brand-500/20 dark:border-gray-700 dark:bg-gray-800/60 dark:text-white/90 dark:focus:bg-gray-900">
                        <?php $__errorArgs = ['nama_syarikat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1.5 text-sm text-error-600 dark:text-error-400"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="md:col-span-2">
                        <div class="border-t border-gray-100 pt-1 dark:border-gray-800"></div>
                        <label for="logo" class="mt-3 mb-1.5 block text-sm font-semibold text-gray-800 dark:text-white/90"><?php echo e(__('Logo Syarikat')); ?></label>
                        <div class="flex flex-wrap items-center gap-4">
                            <?php if($company?->logo_path): ?>
                                <div class="flex h-20 w-36 items-center justify-center rounded-xl border border-gray-200 bg-white p-2 dark:border-gray-700 dark:bg-gray-800">
                                    <img src="<?php echo e(asset('storage/' . $company->logo_path)); ?>" alt="<?php echo e(__('Logo Syarikat')); ?>" class="max-h-full max-w-full object-contain">
                                </div>
                            <?php endif; ?>
                            <div class="min-w-0 flex-1">
                                <input id="logo" name="logo" type="file" accept=".jpg,.jpeg,.png,.svg,image/jpeg,image/png,image/svg+xml" class="block w-full rounded-xl border border-gray-200 bg-gray-50/70 px-4 py-2.5 text-sm text-gray-700 file:me-4 file:rounded-lg file:border-0 file:bg-brand-50 file:px-3 file:py-2 file:text-sm file:font-medium file:text-brand-700 dark:border-gray-700 dark:bg-gray-800/60 dark:text-gray-300 dark:file:bg-brand-500/15 dark:file:text-brand-300">
                                <p class="mt-1.5 text-xs text-gray-500 dark:text-gray-400"><?php echo e(__('Format JPG, PNG atau SVG. Saiz maksimum 2MB.')); ?></p>
                                <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1.5 text-sm text-error-600 dark:text-error-400"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="md:col-span-2"><div class="border-t border-gray-100 pt-1 dark:border-gray-800"></div><h3 class="mt-3 text-sm font-semibold text-gray-800 dark:text-white/90"><?php echo e(__('Maklumat Perhubungan')); ?></h3></div>

                    <?php $__currentLoopData = ['no_telefon' => 'No. Telefon', 'emel' => 'E-mel', 'person_in_charge' => 'Person In Charge']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div>
                            <label for="<?php echo e($field); ?>" class="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-300"><?php echo e(__($label)); ?></label>
                            <input id="<?php echo e($field); ?>" name="<?php echo e($field); ?>" type="<?php echo e($field === 'emel' ? 'email' : ($field === 'no_telefon' ? 'tel' : 'text')); ?>" value="<?php echo e(old($field, $company?->$field)); ?>" class="min-h-11 w-full rounded-xl border border-gray-200 bg-gray-50/70 px-4 py-2.5 text-sm text-gray-800 outline-none transition placeholder:text-gray-400 focus:border-brand-500 focus:bg-white focus:ring-2 focus:ring-brand-500/20 dark:border-gray-700 dark:bg-gray-800/60 dark:text-white/90 dark:focus:bg-gray-900">
                            <?php $__errorArgs = [$field];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1.5 text-sm text-error-600 dark:text-error-400"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="md:col-span-2">
                        <div class="mb-1 border-t border-gray-100 pt-1 dark:border-gray-800"></div>
                        <label for="alamat_syarikat" class="mt-3 block text-sm font-semibold text-gray-800 dark:text-white/90"><?php echo e(__('Alamat Syarikat')); ?></label>
                        <textarea id="alamat_syarikat" name="alamat_syarikat" rows="4" placeholder="Contoh: No. 12, Jalan ..." class="mt-1.5 w-full rounded-xl border border-gray-200 bg-gray-50/70 px-4 py-3 text-sm text-gray-800 outline-none transition placeholder:text-gray-400 focus:border-brand-500 focus:bg-white focus:ring-2 focus:ring-brand-500/20 dark:border-gray-700 dark:bg-gray-800/60 dark:text-white/90 dark:focus:bg-gray-900"><?php echo e(old('alamat_syarikat', $company?->alamat_syarikat)); ?></textarea>
                        <?php $__errorArgs = ['alamat_syarikat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1.5 text-sm text-error-600 dark:text-error-400"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6054fcb7c372d34a0111bcdc769744fa)): ?>
<?php $attributes = $__attributesOriginal6054fcb7c372d34a0111bcdc769744fa; ?>
<?php unset($__attributesOriginal6054fcb7c372d34a0111bcdc769744fa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6054fcb7c372d34a0111bcdc769744fa)): ?>
<?php $component = $__componentOriginal6054fcb7c372d34a0111bcdc769744fa; ?>
<?php unset($__componentOriginal6054fcb7c372d34a0111bcdc769744fa); ?>
<?php endif; ?>

            <div class="flex items-center justify-end gap-3 border-t border-gray-200 pt-5 dark:border-gray-800">
                <button type="submit" class="inline-flex h-11 items-center justify-center rounded-lg bg-brand-500 px-6 text-sm font-medium text-white transition hover:bg-brand-600"><?php echo e(__('Simpan')); ?></button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sebutharga\resources\views\pages\companies\form.blade.php ENDPATH**/ ?>