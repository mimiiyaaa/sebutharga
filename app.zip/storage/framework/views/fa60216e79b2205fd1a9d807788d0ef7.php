<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal497ae120098e047e8d383e0db08b547c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal497ae120098e047e8d383e0db08b547c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.common.document-workspace','data' => ['title' => __('Butiran PO'),'reference' => $order->po_no,'xData' => '{ loginInfoOpen: false }','@keydown.escape.window' => 'loginInfoOpen = false']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.document-workspace'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Butiran PO')),'reference' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->po_no),'x-data' => '{ loginInfoOpen: false }','@keydown.escape.window' => 'loginInfoOpen = false']); ?>
     <?php $__env->slot('referenceActions', null, []); ?> 
        <a href="<?php echo e(route('purchase-order.index')); ?>" class="inline-flex h-9 items-center justify-center rounded-lg border border-gray-200 bg-white px-3 text-theme-xs font-medium text-gray-600 transition hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700"><?php echo e(__('Kembali')); ?></a>
        <div class="relative" @click.outside="loginInfoOpen = false">
            <button type="button" @click="loginInfoOpen = !loginInfoOpen" title="<?php echo e(__('Maklumat Login')); ?>" aria-label="<?php echo e(__('Maklumat Login')); ?>" class="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-gray-200 bg-white text-gray-600 transition hover:border-brand-300 hover:text-brand-600 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 dark:hover:border-brand-700 dark:hover:text-brand-400">
                <svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M12 16v-4m0-4h.01M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"/></svg>
            </button>
            <?php if (isset($component)) { $__componentOriginal138969a60b1852068eba0fb28ea7dddf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal138969a60b1852068eba0fb28ea7dddf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.common.created-by-panel','data' => ['name' => $order->creator_name,'jawatan' => $order->creator_jawatan,'email' => $order->creator_email,'createdAt' => $order->created_at,'documentLabel' => 'PO ini']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.created-by-panel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->creator_name),'jawatan' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->creator_jawatan),'email' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->creator_email),'created-at' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->created_at),'document-label' => 'PO ini']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal138969a60b1852068eba0fb28ea7dddf)): ?>
<?php $attributes = $__attributesOriginal138969a60b1852068eba0fb28ea7dddf; ?>
<?php unset($__attributesOriginal138969a60b1852068eba0fb28ea7dddf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal138969a60b1852068eba0fb28ea7dddf)): ?>
<?php $component = $__componentOriginal138969a60b1852068eba0fb28ea7dddf; ?>
<?php unset($__componentOriginal138969a60b1852068eba0fb28ea7dddf); ?>
<?php endif; ?>
        </div>
     <?php $__env->endSlot(); ?>

    <?php
        $document = $document ?? (json_decode($order->document_data ?? '[]', true) ?: []);
        $issuer = ['Nama Syarikat' => $document['issuer_name'] ?? config('purchase_order.issuer_name'), 'Nombor Telefon' => $document['issuer_phone'] ?? config('purchase_order.issuer_phone'), 'E-mel' => $document['issuer_email'] ?? config('purchase_order.issuer_email'), 'Alamat Syarikat' => $document['issuer_address'] ?? config('purchase_order.issuer_address')];
        $supplier = ['Nama Syarikat' => $order->company_name, 'Nombor Telefon' => $order->supplier_phone, 'Untuk Perhatian' => $order->attention_supplier, 'Alamat' => $order->supplier_address];
        $termsConditions = preg_replace('/^\s*\d+\.\s*$/m', '', (string) $order->terms_conditions);
    ?>

    <section class="mb-6 overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]">
        <div class="flex items-center justify-between border-b border-gray-100 px-6 py-5 dark:border-gray-800">
            <h2 class="text-lg font-semibold text-gray-800 dark:text-white/90"><?php echo e(__('Maklumat Pesanan Belian')); ?></h2>
            <div class="flex shrink-0 flex-wrap items-center justify-end gap-2">
                <a href="<?php echo e(route('purchase-order.preview', $order->purchase_order_id)); ?>" class="inline-flex h-10 items-center rounded-lg border border-gray-300 bg-gray-50 px-3 text-sm font-medium text-gray-700 transition hover:bg-gray-100 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700"><?php echo e(__('Pratonton')); ?></a>
                <a href="<?php echo e(route('purchase-order.edit', ['id' => $order->purchase_order_id, 'from' => 'show'])); ?>" class="inline-flex h-10 items-center rounded-lg bg-brand-500 px-3 text-sm font-medium text-white transition hover:bg-brand-600"><?php echo e(__('Edit')); ?></a>
            </div>
        </div>
        <div class="grid grid-cols-1 gap-6 p-6 sm:grid-cols-2 xl:grid-cols-3">
            <?php $__currentLoopData = ['No. PO' => $order->po_no, 'Tarikh PO' => $order->po_date ? \Carbon\Carbon::parse($order->po_date)->format('d/m/Y') : '—', 'Pembekal' => $order->company_name, 'No. Sebut Harga' => $order->quotation_reference_no, 'Kemaskini Terakhir' => $order->updated_at ? \Carbon\Carbon::parse($order->updated_at)->format('d/m/Y H:i') : '—', 'Status PO' => $order->status_po]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div><p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(__($label)); ?></p><p class="mt-2 text-base font-medium text-gray-800 dark:text-white/90"><?php echo e($value ?: '—'); ?></p></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="grid grid-cols-1 gap-5 border-t border-gray-100 p-6 dark:border-gray-800 lg:grid-cols-2">
            <?php $__currentLoopData = ['Maklumat Syarikat Pengeluar' => $issuer, 'Maklumat Pembekal' => $supplier]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section => $fields): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <section class="border-t border-gray-100 pt-5 first:border-t-0 first:pt-0 dark:border-gray-800">
                    <h3 class="mb-5 text-base font-semibold text-gray-800 dark:text-white/90"><?php echo e(__($section)); ?></h3>
                    <div class="grid grid-cols-1 gap-5 sm:grid-cols-2">
                        <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sm:col-span-2' => in_array($label, ['Alamat Syarikat', 'Alamat'])]); ?>"><p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(__($label)); ?></p><p class="mt-2 whitespace-pre-line break-words text-base font-medium text-gray-800 dark:text-white/90"><?php echo e($value ?: '—'); ?></p></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </section>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="grid grid-cols-1 gap-5 border-t border-gray-100 p-6 dark:border-gray-800 lg:grid-cols-2">
            <section class="border-t border-gray-100 pt-5 first:border-t-0 first:pt-0 dark:border-gray-800">
                <h3 class="mb-5 text-base font-semibold text-gray-800 dark:text-white/90"><?php echo e(__('Maklumat Penghantaran')); ?></h3>
                <div class="grid grid-cols-1 gap-5 sm:grid-cols-2"><div><p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('Nama Syarikat Penghantar')); ?></p><p class="mt-2 text-base font-medium text-gray-800 dark:text-white/90"><?php echo e($document['delivery_company'] ?? config('purchase_order.issuer_name')); ?></p></div><div><p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('Nombor Telefon Penghantar')); ?></p><p class="mt-2 text-base font-medium text-gray-800 dark:text-white/90"><?php echo e($document['delivery_phone'] ?? config('purchase_order.issuer_phone')); ?></p></div><div class="sm:col-span-2"><p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('Alamat Penghantaran')); ?></p><p class="mt-2 whitespace-pre-line break-words text-base font-medium text-gray-800 dark:text-white/90"><?php echo e($order->delivery_address ?: config('purchase_order.issuer_address')); ?></p></div><div><p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('Untuk Perhatian')); ?></p><p class="mt-2 text-base font-medium text-gray-800 dark:text-white/90"><?php echo e($order->attention_delivery ?: config('purchase_order.delivery_attention') ?: '—'); ?></p></div></div>
            </section>
            <section class="border-t border-gray-100 pt-5 dark:border-gray-800 lg:border-t-0 lg:border-s lg:ps-6 lg:pt-0">
                <h3 class="mb-5 text-base font-semibold text-gray-800 dark:text-white/90"><?php echo e(__('Pengesahan PO')); ?></h3>
                <div class="grid grid-cols-1 gap-5 sm:grid-cols-2"><div><p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('Disediakan Oleh')); ?></p><p class="mt-2 text-base font-medium text-gray-800 dark:text-white/90"><?php echo e($order->prepared_by ?: '—'); ?></p></div><div><p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('Diluluskan Oleh')); ?></p><p class="mt-2 text-base font-medium text-gray-800 dark:text-white/90"><?php echo e($order->approved_by ?: '—'); ?></p></div></div>
            </section>
        </div>
        <div class="border-t border-gray-100 p-6 dark:border-gray-800"><h3 class="mb-3 text-base font-semibold text-gray-800 dark:text-white/90"><?php echo e(__('Terma dan Syarat Pembelian')); ?></h3><p class="whitespace-pre-line text-base leading-6 text-gray-700 dark:text-gray-300"><?php echo e(trim($termsConditions) ?: '—'); ?></p></div>
    </section>

    <section class="mb-6 overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]">
        <div class="flex items-center justify-between border-b border-gray-100 px-6 py-5 dark:border-gray-800"><div><h2 class="text-lg font-semibold text-gray-800 dark:text-white/90"><?php echo e(__('Item Pesanan Belian')); ?></h2><p class="mt-1 text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('Maklumat item PO ini')); ?></p></div></div>
        <div class="custom-scrollbar overflow-x-auto"><table class="w-full min-w-[760px] text-start text-theme-sm"><thead class="bg-error-800 text-white dark:bg-error-900 dark:text-white"><tr><th class="w-14 px-5 py-4 text-center text-theme-xs font-semibold"><?php echo e(__('Bil')); ?></th><th class="px-5 py-4 text-start text-theme-xs font-semibold"><?php echo e(__('Perihal Barangan')); ?></th><th class="px-5 py-4 text-start text-theme-xs font-semibold"><?php echo e(__('Kuantiti')); ?></th><th class="px-5 py-4 text-start text-theme-xs font-semibold"><?php echo e(__('Unit')); ?></th><th class="px-5 py-4 text-end text-theme-xs font-semibold"><?php echo e(__('Harga Seunit (RM)')); ?></th><th class="px-5 py-4 text-end text-theme-xs font-semibold"><?php echo e(__('Jumlah (RM)')); ?></th></tr></thead><tbody><?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr class="border-b border-gray-100 even:bg-gray-50/60 hover:bg-brand-50/40 dark:border-gray-800 dark:even:bg-gray-800/30 dark:hover:bg-brand-500/5"><td class="px-5 py-5 text-center tabular-nums text-gray-400 dark:text-gray-500"><?php echo e($loop->iteration); ?></td><td class="px-5 py-5 font-medium leading-6 text-gray-800 dark:text-gray-200"><p class="whitespace-pre-line break-words"><?php echo e($item->item_description); ?></p></td><td class="px-5 py-5 text-gray-600 dark:text-gray-300"><?php echo e($item->quantity); ?></td><td class="px-5 py-5 text-gray-600 dark:text-gray-300"><?php echo e($item->unit); ?></td><td class="px-5 py-5 text-end tabular-nums text-gray-600 dark:text-gray-300">RM <?php echo e(number_format((float) $item->unit_price, 2)); ?></td><td class="px-5 py-5 text-end font-semibold tabular-nums text-gray-900 dark:text-white/90">RM <?php echo e(number_format((float) $item->subtotal, 2)); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="6" class="px-5 py-6 text-center text-gray-500 dark:text-gray-400"><?php echo e(__('Tiada item')); ?></td></tr><?php endif; ?></tbody></table></div>
        <div class="flex justify-end border-t border-gray-100 bg-gray-50 p-6 dark:border-gray-800 dark:bg-gray-900"><div class="w-full max-w-sm space-y-2 text-theme-sm text-gray-700 dark:text-gray-300"><div class="flex justify-between"><span><?php echo e(__('Jumlah Kasar')); ?></span><span class="tabular-nums">RM <?php echo e(number_format((float) $order->gross_amount, 2)); ?></span></div><div class="flex justify-between"><span><?php echo e(__('Jumlah Diskaun')); ?></span><span class="tabular-nums">RM <?php echo e(number_format((float) $order->discount_amount, 2)); ?></span></div><div class="flex justify-between"><span><?php echo e(__('SST')); ?> (<?php echo e((float) $order->sst_percent); ?>%)</span><span class="tabular-nums">RM <?php echo e(number_format((float) $order->sst_amount, 2)); ?></span></div><div class="flex justify-between border-t border-gray-200 pt-3 text-lg font-semibold text-gray-900 dark:border-gray-700 dark:text-white/90"><span><?php echo e(__('Jumlah Bersih')); ?></span><span class="tabular-nums">RM <?php echo e(number_format((float) $order->net_amount, 2)); ?></span></div></div></div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal497ae120098e047e8d383e0db08b547c)): ?>
<?php $attributes = $__attributesOriginal497ae120098e047e8d383e0db08b547c; ?>
<?php unset($__attributesOriginal497ae120098e047e8d383e0db08b547c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal497ae120098e047e8d383e0db08b547c)): ?>
<?php $component = $__componentOriginal497ae120098e047e8d383e0db08b547c; ?>
<?php unset($__componentOriginal497ae120098e047e8d383e0db08b547c); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sebutharga\resources\views\pages\purchase-order\show.blade.php ENDPATH**/ ?>