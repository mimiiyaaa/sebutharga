<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginald07245451647f5715f9bac44fc38d4f4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald07245451647f5715f9bac44fc38d4f4 = $attributes; } ?>
<?php $component = App\View\Components\Common\PageBreadcrumb::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.page-breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Common\PageBreadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageTitle' => 'Sebut Harga Draf']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald07245451647f5715f9bac44fc38d4f4)): ?>
<?php $attributes = $__attributesOriginald07245451647f5715f9bac44fc38d4f4; ?>
<?php unset($__attributesOriginald07245451647f5715f9bac44fc38d4f4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald07245451647f5715f9bac44fc38d4f4)): ?>
<?php $component = $__componentOriginald07245451647f5715f9bac44fc38d4f4; ?>
<?php unset($__componentOriginald07245451647f5715f9bac44fc38d4f4); ?>
<?php endif; ?>

    <div class="space-y-6" x-data="{
        addQuotationOpen: false,
    }" @keydown.escape.window="addQuotationOpen = false">
        <?php if (isset($component)) { $__componentOriginal6e5626e553feb0bf161f21170a535399 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6e5626e553feb0bf161f21170a535399 = $attributes; } ?>
<?php $component = App\View\Components\Common\ComponentCard::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.component-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Common\ComponentCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Senarai Sebut Harga Draf']); ?>
            <?php if (isset($component)) { $__componentOriginalcab008a551b5fce9876277e4f086ae8f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcab008a551b5fce9876277e4f086ae8f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tables.basic-tables.sebutharga-table','data' => ['quotations' => $quotations]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tables.basic-tables.sebutharga-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['quotations' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($quotations)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcab008a551b5fce9876277e4f086ae8f)): ?>
<?php $attributes = $__attributesOriginalcab008a551b5fce9876277e4f086ae8f; ?>
<?php unset($__attributesOriginalcab008a551b5fce9876277e4f086ae8f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcab008a551b5fce9876277e4f086ae8f)): ?>
<?php $component = $__componentOriginalcab008a551b5fce9876277e4f086ae8f; ?>
<?php unset($__componentOriginalcab008a551b5fce9876277e4f086ae8f); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6e5626e553feb0bf161f21170a535399)): ?>
<?php $attributes = $__attributesOriginal6e5626e553feb0bf161f21170a535399; ?>
<?php unset($__attributesOriginal6e5626e553feb0bf161f21170a535399); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6e5626e553feb0bf161f21170a535399)): ?>
<?php $component = $__componentOriginal6e5626e553feb0bf161f21170a535399; ?>
<?php unset($__componentOriginal6e5626e553feb0bf161f21170a535399); ?>
<?php endif; ?>

        <div x-cloak x-show="addQuotationOpen" x-transition.opacity class="fixed inset-0 z-999999 flex items-center justify-center overflow-y-auto bg-gray-900/50 p-4 sm:p-8" @click.self="addQuotationOpen = false">
            <section x-show="addQuotationOpen" x-transition class="w-full max-w-2xl overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-theme-xl dark:border-gray-700 dark:bg-gray-900" role="dialog" aria-modal="true" aria-labelledby="add-quotation-title">
                <div class="flex items-start justify-between gap-4 border-b border-gray-100 px-5 py-4 dark:border-gray-800 sm:px-6">
                    <div>
                        <h2 id="add-quotation-title" class="text-lg font-semibold text-gray-800 dark:text-white/90"><?php echo e(__('Tambah Sebut Harga Draf')); ?></h2>
                        <p class="mt-1 text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('Pilih cara untuk mula.')); ?></p>
                    </div>
                    <button type="button" @click="addQuotationOpen = false" class="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-gray-200 text-xl text-gray-500 transition hover:bg-gray-50 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-800" aria-label="<?php echo e(__('Tutup')); ?>">&times;</button>
                </div>

                <div class="max-h-[calc(100dvh-8rem)] space-y-4 overflow-y-auto p-5 sm:p-6">
                    <div class="grid grid-cols-1 gap-3 md:grid-cols-2">
                        <a href="<?php echo e(route('sebut-harga.create')); ?>" class="group rounded-xl border-2 border-brand-200 bg-brand-50/50 p-4 transition hover:border-brand-500 hover:bg-brand-50 dark:border-brand-700/60 dark:bg-brand-500/10 dark:hover:bg-brand-500/15">
                            <div class="flex items-center justify-between gap-3"><div><p class="text-sm font-semibold text-gray-800 dark:text-white/90"><?php echo e(__('Buat Sebut Harga Baru')); ?></p><p class="mt-1 text-xs text-gray-500 dark:text-gray-400"><?php echo e(__('Terus buka form kosong.')); ?></p></div><span class="text-2xl text-brand-500">→</span></div>
                        </a>
                        <a href="<?php echo e(route('sebut-harga', ['add' => 1])); ?>" class="group rounded-xl border-2 border-gray-200 bg-white p-4 text-start transition hover:border-brand-300 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-900 dark:hover:bg-gray-800">
                            <div class="flex items-center justify-between gap-3"><div><p class="text-sm font-semibold text-gray-800 dark:text-white/90"><?php echo e(__('Guna Sebut Harga Sedia Ada')); ?></p><p class="mt-1 text-xs text-gray-500 dark:text-gray-400"><?php echo e(__('Buka senarai Draf atau Final.')); ?></p></div><span class="text-xl text-gray-400 transition group-hover:translate-x-1">→</span></div>
                        </a>
                    </div>

                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sebutharga\resources\views\pages\sebut-harga.blade.php ENDPATH**/ ?>